package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Tela principal: imagem da câmera na tela toda, controles por cima.

import android.app.Activity
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.text.Html
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), CamService.Ui {

    private var svc: CamService? = null
    private var bound = false
    private var visible = false
    private val main = Handler(Looper.getMainLooper())

    private lateinit var texture: TextureView
    private lateinit var recBorder: View
    private lateinit var logo: ImageView
    private lateinit var timerPill: LinearLayout
    private lateinit var timerText: TextView
    private lateinit var badgeQuality: TextView
    private lateinit var badgeHdr: TextView
    private lateinit var listenPill: LinearLayout
    private lateinit var listenText: TextView
    private val listenBars = mutableListOf<View>()
    private lateinit var preInclPill: TextView
    private lateinit var centerToast: LinearLayout
    private lateinit var centerToastText: TextView
    private lateinit var preRecPill: LinearLayout
    private lateinit var preRecText: TextView
    private lateinit var zoomRow: LinearLayout
    private val zoomButtons = mutableListOf<Pair<Float, TextView>>()
    private lateinit var lockHint: TextView
    private lateinit var markBtn: TextView
    private lateinit var modeRow: LinearLayout
    private lateinit var modePhoto: TextView
    private lateinit var modeVideo: TextView
    private lateinit var gallery: ImageView
    private lateinit var darkBtn: FrameLayout
    private lateinit var shutter: ShutterButton
    private lateinit var switchBtn: FrameLayout
    private lateinit var photoBtn: FrameLayout
    private lateinit var darkOverlay: FrameLayout

    private var galleryUri: Uri? = null
    private var galleryIsVideo = true
    private var thumbUri: Uri? = null
    private var lastOverlayTap = 0L
    private var lastTouch = System.currentTimeMillis()
    private var lastDarkMove = 0L
    private lateinit var offPanel: FrameLayout
    private lateinit var darkBox: LinearLayout
    private lateinit var darkDot: View
    private lateinit var darkText: TextView
    private lateinit var darkHint: TextView
    private val rnd = java.util.Random()
    private val prefs by lazy { getSharedPreferences(Prefs.FILE, MODE_PRIVATE) }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            svc = (binder as CamService.LocalBinder).service
            svc?.ui = this@MainActivity
            onState()
            attachIfReady()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val s = svc
            val now = System.currentTimeMillis()
            if (s != null && s.engine.isRecording) {
                val sec = ((now - s.engine.recStartMs) / 1000).coerceAtLeast(0)
                timerText.text = String.format("%02d:%02d", sec / 60, sec % 60)
            }
            // Tela escura automática depois de 30 s sem tocar
            if (s != null && visible && darkOverlay.visibility != View.VISIBLE &&
                prefs.getBoolean("autodark", true) && now - lastTouch > 30_000
            ) showDark()
            if (darkOverlay.visibility == View.VISIBLE) updateDark(now)
            main.postDelayed(this, 500)
        }
    }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!prefs.getBoolean("welcomed", false) || !Ui062.hasPermissions(this)) {
            startActivity(Intent(this, WelcomeActivity::class.java))
            finish()
            return
        }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Ui062.BG
        buildUi()
        if (CamService.running) bindToService() else showOff()
        findLatestMedia()
    }

    // ------------------------------------------------------------------ ligar e desligar

    private fun bindToService() {
        if (bound) return
        bound = bindService(Intent(this, CamService::class.java), conn, Context.BIND_AUTO_CREATE)
    }

    private fun powerOn() {
        offPanel.visibility = View.GONE
        listenText.text = "Ligando..."
        lastTouch = System.currentTimeMillis()
        startForegroundService(Intent(this, CamService::class.java))
        bindToService()
        updateKeepOn()
    }

    private fun powerOff() {
        val s = svc
        if (s == null) {
            showOff()
            return
        }
        val rec = s.engine.isRecording
        s.shutdown() // chama onExit(), que mostra a tela de desligado
        if (rec) onMessage("Vídeo salvo e app desligado")
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (_: Exception) {
        "?"
    }

    private fun showOff() {
        hideDark()
        offPanel.visibility = View.VISIBLE
        updateKeepOn()
    }

    /** Mantém a tela acesa (para a tela escura funcionar) só enquanto o app está ligado. */
    private fun updateKeepOn() {
        val on = offPanel.visibility != View.VISIBLE && prefs.getBoolean("autodark", true)
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        lastTouch = System.currentTimeMillis()
        return super.dispatchTouchEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        if (!::texture.isInitialized) return
        visible = true
        lastTouch = System.currentTimeMillis()
        if (!CamService.running && offPanel.visibility != View.VISIBLE) showOff()
        updateKeepOn()
        attachIfReady()
        main.post(ticker)
        onState()
    }

    override fun onPause() {
        if (::texture.isInitialized) {
            visible = false
            main.removeCallbacks(ticker)
            hideDark()
            svc?.engine?.detachPreview()
        }
        super.onPause()
    }

    override fun onDestroy() {
        svc?.ui = null
        if (bound) {
            try {
                unbindService(conn)
            } catch (_: Exception) {
            }
            bound = false
        }
        super.onDestroy()
    }

    private fun attachIfReady() {
        val s = svc ?: return
        if (!visible) return
        val st = texture.surfaceTexture ?: return
        if (!texture.isAvailable) return
        s.engine.attachPreview(st)
        updateTransform()
    }

    /** Faz a imagem preencher a tela toda sem esticar (corta as bordas). */
    private fun updateTransform() {
        val vw = texture.width.toFloat()
        val vh = texture.height.toFloat()
        if (vw <= 0f || vh <= 0f) return
        val size = svc?.engine?.videoSize ?: Size(1920, 1080)
        val contentAspect = size.height.toFloat() / size.width.toFloat()
        val viewAspect = vw / vh
        val m = Matrix()
        if (viewAspect < contentAspect) {
            m.setScale((vh * contentAspect) / vw, 1f, vw / 2f, vh / 2f)
        } else {
            m.setScale(1f, (vw / contentAspect) / vh, vw / 2f, vh / 2f)
        }
        texture.setTransform(m)
    }

    // ------------------------------------------------------------------ eventos do serviço

    override fun onState() {
        if (!::texture.isInitialized) return
        val s = svc ?: return
        val e = s.engine
        val rec = e.isRecording
        val photoMode = prefs.getString("mode", "video") == "photo"

        recBorder.visibility = if (rec) View.VISIBLE else View.GONE
        logo.visibility = if (rec) View.GONE else View.VISIBLE
        timerPill.visibility = if (rec) View.VISIBLE else View.GONE

        badgeQuality.text = "${e.videoSize.height}p · 30"
        badgeHdr.visibility = if (e.useHdr && e.hdrSupported) View.VISIBLE else View.GONE

        when {
            !s.voiceReady -> setListen(Ui062.YELLOW, s.voiceStatus, Ui062.YELLOW)
            rec -> setListen(
                Ui062.RED,
                "Gravando · diga <font color='#FF9A92'><b>“${s.say("parar")}”</b></font>, “foto” ou “marca”",
                Ui062.RED
            )
            else -> setListen(Ui062.GREEN, "Ouvindo · diga <font color='#7CF0A8'><b>“${s.say("gravar")}”</b></font>", Ui062.GREEN)
        }

        val pre = e.preRecSec
        preInclPill.text = "Inclui $pre s antes do comando"
        preInclPill.visibility = if (rec && pre > 0) View.VISIBLE else View.GONE
        preRecText.text = fromHtml("Guardando os últimos <b>$pre s</b> · <font color='#FBC403'><b>Salvar agora</b></font>")
        preRecPill.visibility = if (!rec && pre > 0) View.VISIBLE else View.GONE

        for ((z, b) in zoomButtons) {
            val on = kotlin.math.abs(e.zoom - z) < 0.01f
            b.visibility = if (z < 1f && !e.ultraWideSupported) View.GONE else View.VISIBLE
            b.setTextColor(if (on) Ui062.YELLOW else Ui062.MUTED)
            b.background = Ui062.oval(if (on) Color.parseColor("#D9050505") else Color.parseColor("#99050505"))
        }

        lockHint.visibility = if (rec) View.VISIBLE else View.GONE
        markBtn.visibility = if (rec) View.VISIBLE else View.GONE
        modeRow.visibility = if (rec) View.INVISIBLE else View.VISIBLE
        modePhoto.setTextColor(if (photoMode) Ui062.YELLOW else Color.parseColor("#7D8790"))
        modeVideo.setTextColor(if (!photoMode) Ui062.YELLOW else Color.parseColor("#7D8790"))

        shutter.mode = when {
            rec -> ShutterButton.Mode.RECORDING
            photoMode -> ShutterButton.Mode.PHOTO
            else -> ShutterButton.Mode.VIDEO
        }
        shutter.contentDescription = if (rec) "Parar" else if (photoMode) "Tirar foto" else "Gravar"
        gallery.visibility = if (rec) View.GONE else View.VISIBLE
        darkBtn.visibility = if (rec) View.VISIBLE else View.GONE
        switchBtn.visibility = if (rec) View.GONE else View.VISIBLE
        photoBtn.visibility = if (rec) View.VISIBLE else View.GONE

        s.lastUri?.let {
            galleryUri = it
            galleryIsVideo = s.lastIsVideo
        }
        loadThumb(galleryUri)
        updateTransform()
    }

    override fun onMessage(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onPhotoSaved() {
        val rec = svc?.engine?.isRecording == true
        centerToastText.text = if (rec) "Foto salva sem parar o vídeo" else "Foto salva"
        centerToast.visibility = View.VISIBLE
        main.removeCallbacks(hideToast)
        main.postDelayed(hideToast, 1600)
    }

    private val hideToast = Runnable { centerToast.visibility = View.GONE }

    override fun onExit() {
        svc?.ui = null
        svc = null
        if (bound) {
            try {
                unbindService(conn)
            } catch (_: Exception) {
            }
            bound = false
        }
        showOff()
    }

    private fun setListen(barColor: Int, html: String, borderColor: Int) {
        listenText.text = fromHtml(html)
        for (b in listenBars) b.background = Ui062.shape(this, barColor, 2)
        listenPill.background = Ui062.shape(
            this, Ui062.GLASS, 999,
            Color.argb(115, Color.red(borderColor), Color.green(borderColor), Color.blue(borderColor)), 1
        )
    }

    private fun fromHtml(s: String): CharSequence = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY)

    // ------------------------------------------------------------------ galeria

    private fun findLatestMedia() {
        Thread {
            var best: Triple<Uri, Long, Boolean>? = null
            for ((coll, isVideo) in listOf(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI to true,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI to false
            )) {
                try {
                    contentResolver.query(
                        coll,
                        arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATE_ADDED),
                        "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                        arrayOf("%${CameraEngine.FOLDER}%"),
                        "${MediaStore.MediaColumns.DATE_ADDED} DESC"
                    )?.use { c ->
                        if (c.moveToFirst()) {
                            val date = c.getLong(1)
                            if (best == null || date > best!!.second) {
                                best = Triple(ContentUris.withAppendedId(coll, c.getLong(0)), date, isVideo)
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }
            val found = best ?: return@Thread
            main.post {
                if (galleryUri == null) {
                    galleryUri = found.first
                    galleryIsVideo = found.third
                    loadThumb(galleryUri)
                }
            }
        }.start()
    }

    private fun loadThumb(uri: Uri?) {
        if (uri == null || uri == thumbUri) return
        thumbUri = uri
        Thread {
            val bmp = try {
                contentResolver.loadThumbnail(uri, Size(200, 200), null)
            } catch (_: Exception) {
                null
            }
            main.post { if (bmp != null) gallery.setImageBitmap(bmp) }
        }.start()
    }

    /** Abre a lista "Meus vídeos", onde dá para assistir e editar. */
    private fun openGallery() {
        startActivity(Intent(this, VideosActivity::class.java))
    }

    // ------------------------------------------------------------------ tela apagada

    private fun showDark() {
        if (svc == null) return
        darkOverlay.visibility = View.VISIBLE
        lastDarkMove = 0L
        updateDark(System.currentTimeMillis())
        val lp = window.attributes
        lp.screenBrightness = 0.01f
        window.attributes = lp
    }

    /** Atualiza o aviso da tela escura e muda ele de lugar (protege a tela de manchas). */
    private fun updateDark(now: Long) {
        val s = svc
        if (s == null) {
            hideDark()
            return
        }
        val rec = s.engine.isRecording
        if (rec) {
            val sec = ((now - s.engine.recStartMs) / 1000).coerceAtLeast(0)
            darkText.text = String.format("GRAVANDO  %02d:%02d", sec / 60, sec % 60)
            darkText.setTextColor(Color.parseColor("#B33A32"))
            darkDot.background = Ui062.oval(Color.parseColor("#B33A32"))
        } else {
            darkText.text = "062 Cam ouvindo · diga “${s.say("gravar")}”"
            darkText.setTextColor(Color.parseColor("#2E8A55"))
            darkDot.background = Ui062.oval(Color.parseColor("#2E8A55"))
        }
        darkDot.alpha = if ((now / 1000) % 2 == 0L) 1f else 0.25f
        if (now - lastDarkMove > 30_000) {
            lastDarkMove = now
            darkBox.post {
                val maxX = (darkOverlay.width - darkBox.width).coerceAtLeast(1)
                val maxY = (darkOverlay.height - darkBox.height - dp(60)).coerceAtLeast(1)
                darkBox.translationX = rnd.nextInt(maxX).toFloat()
                darkBox.translationY = (dp(40) + rnd.nextInt(maxY)).toFloat()
            }
        }
    }

    private fun hideDark() {
        if (!::darkOverlay.isInitialized || darkOverlay.visibility != View.VISIBLE) return
        darkOverlay.visibility = View.GONE
        val lp = window.attributes
        lp.screenBrightness = -1f
        window.attributes = lp
    }

    // ------------------------------------------------------------------ montagem da tela

    private fun dp(v: Int) = Ui062.dp(this, v)

    private fun iconButton(kind: IconView.Kind, sizeDp: Int, bg: GradientDrawable, label: String, iconDp: Int = 22, onClick: () -> Unit): FrameLayout =
        FrameLayout(this).apply {
            background = bg
            contentDescription = label
            isClickable = true
            setOnClickListener { onClick() }
            addView(IconView(context, kind), FrameLayout.LayoutParams(dp(iconDp), dp(iconDp), Gravity.CENTER))
            layoutParams = ViewGroup.LayoutParams(dp(sizeDp), dp(sizeDp))
        }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Ui062.BG) }

        // Imagem da câmera
        texture = TextureView(this)
        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) = attachIfReady()
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) = updateTransform()
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                svc?.engine?.detachPreview()
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        root.addView(texture, FrameLayout.LayoutParams(-1, -1))

        recBorder = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(3), Ui062.RED)
            }
            visibility = View.GONE
        }
        root.addView(recBorder, FrameLayout.LayoutParams(-1, -1))

        // ---------- topo
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(14), dp(16), 0)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        logo = ImageView(this).apply {
            setImageResource(R.drawable.logo_062)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = Ui062.oval(Color.BLACK)
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            contentDescription = "062 Fish"
        }
        bar.addView(logo, LinearLayout.LayoutParams(dp(40), dp(40)))
        timerPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui062.shape(context, Ui062.RED, 10)
            setPadding(dp(12), dp(7), dp(12), dp(7))
            visibility = View.GONE
        }
        timerPill.addView(View(this).apply { background = Ui062.oval(Color.WHITE) }, LinearLayout.LayoutParams(dp(9), dp(9)).apply {
            marginEnd = dp(8)
        })
        timerText = Ui062.text(this, "00:00", 17f, Color.WHITE, true)
        timerPill.addView(timerText)
        bar.addView(timerPill)
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        badgeQuality = Ui062.badge(this, "1080p · 30")
        bar.addView(badgeQuality, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
        badgeHdr = Ui062.badge(this, "HDR")
        bar.addView(badgeHdr, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
        bar.addView(
            iconButton(IconView.Kind.POWER, 38, Ui062.shape(this, Ui062.GLASS, 10, Ui062.GLASS_LINE, 1), "Desligar o app", 20) {
                powerOff()
            },
            LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(6) }
        )
        bar.addView(
            iconButton(IconView.Kind.GEAR, 38, Ui062.shape(this, Ui062.GLASS, 10, Ui062.GLASS_LINE, 1), "Ajustes", 20) {
                startActivity(Intent(this, SettingsActivity::class.java))
            }
        )
        top.addView(bar, LinearLayout.LayoutParams(-1, -2))

        listenPill = Ui062.pill(this)
        val bars = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
        }
        for (h in listOf(6, 12, 9, 14)) {
            val v = View(this)
            listenBars.add(v)
            bars.addView(v, LinearLayout.LayoutParams(dp(3), dp(h)).apply { marginEnd = dp(2) })
        }
        listenPill.addView(bars, LinearLayout.LayoutParams(-2, dp(14)).apply { marginEnd = dp(8) })
        listenText = Ui062.text(this, "Iniciando...", 13f)
        listenPill.addView(listenText)
        top.addView(listenPill, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) })

        preInclPill = Ui062.text(this, "", 12f, Color.parseColor("#C9D1D9")).apply {
            background = Ui062.shape(context, Color.parseColor("#99050505"), 999)
            setPadding(dp(10), dp(5), dp(10), dp(5))
            visibility = View.GONE
        }
        top.addView(preInclPill, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ---------- aviso no centro
        centerToast = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui062.shape(context, Color.parseColor("#D1050505"), 14, Ui062.GLASS_LINE, 1)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            visibility = View.GONE
        }
        centerToast.addView(IconView(this, IconView.Kind.CAMERA, Ui062.YELLOW), LinearLayout.LayoutParams(dp(18), dp(18)).apply {
            marginEnd = dp(8)
        })
        centerToastText = Ui062.text(this, "Foto salva", 14f, Ui062.TEXT, true)
        centerToast.addView(centerToastText)
        root.addView(centerToast, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // ---------- base
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        preRecPill = Ui062.pill(this)
        preRecPill.addView(IconView(this, IconView.Kind.HISTORY, Ui062.YELLOW), LinearLayout.LayoutParams(dp(14), dp(14)).apply {
            marginEnd = dp(6)
        })
        preRecText = Ui062.text(this, "", 12f, Color.parseColor("#C9D1D9"))
        preRecPill.addView(preRecText)
        preRecPill.isClickable = true
        preRecPill.contentDescription = "Salvar os últimos segundos"
        preRecPill.setOnClickListener { svc?.saveClip() }
        bottom.addView(preRecPill, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(14) })

        zoomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        for ((z, label) in listOf(0.5f to "0,5", 1f to "1×", 2f to "2×")) {
            val b = Ui062.text(this, label, 13f, Ui062.MUTED, true).apply {
                gravity = Gravity.CENTER
                contentDescription = "Zoom $label"
                setOnClickListener { svc?.setZoom(z) }
            }
            zoomButtons.add(z to b)
            zoomRow.addView(b, LinearLayout.LayoutParams(dp(44), dp(44)).apply {
                marginStart = dp(4)
                marginEnd = dp(4)
            })
        }
        bottom.addView(zoomRow, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(18) })

        lockHint = Ui062.text(this, "Pode apagar ou bloquear a tela · continua gravando", 12f, Color.parseColor("#C9D1D9")).apply {
            background = Ui062.shape(context, Color.parseColor("#99050505"), 999)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            visibility = View.GONE
        }
        markBtn = Ui062.text(this, "Marcar momento", 14f, Ui062.YELLOW, true).apply {
            gravity = Gravity.CENTER
            background = Ui062.shape(context, Color.parseColor("#D9050505"), 999, Ui062.YELLOW, 1)
            setPadding(dp(18), 0, dp(18), 0)
            visibility = View.GONE
            setOnClickListener { svc?.mark() }
        }
        bottom.addView(markBtn, LinearLayout.LayoutParams(-2, dp(44)).apply { bottomMargin = dp(10) })
        bottom.addView(lockHint, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(18) })

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Ui062.BG)
                val r = Ui062.dpf(context, 24f)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
            setPadding(dp(24), dp(14), dp(24), dp(26))
        }
        modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        modePhoto = Ui062.text(this, "FOTO", 13f, Ui062.MUTED, true).apply {
            letterSpacing = 0.06f
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener {
                prefs.edit().putString("mode", "photo").apply()
                onState()
            }
        }
        modeVideo = Ui062.text(this, "VÍDEO", 13f, Ui062.YELLOW, true).apply {
            letterSpacing = 0.06f
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener {
                prefs.edit().putString("mode", "video").apply()
                onState()
            }
        }
        modeRow.addView(modePhoto)
        modeRow.addView(modeVideo)
        panel.addView(modeRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val left = FrameLayout(this)
        gallery = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = Ui062.shape(context, Color.parseColor("#2A2A2A"), 14, Color.parseColor("#38FFFFFF"), 2)
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            contentDescription = "Galeria"
            setOnClickListener { openGallery() }
        }
        left.addView(gallery, FrameLayout.LayoutParams(dp(54), dp(54)))
        darkBtn = iconButton(IconView.Kind.LOCK, 54, Ui062.oval(Color.parseColor("#1A1A1A")), "Apagar a tela", 20) { showDark() }
        darkBtn.visibility = View.GONE
        left.addView(darkBtn, FrameLayout.LayoutParams(dp(54), dp(54)))
        controls.addView(left, LinearLayout.LayoutParams(dp(54), dp(54)))
        controls.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        shutter = ShutterButton(this).apply {
            isClickable = true
            setOnClickListener {
                val s = svc ?: return@setOnClickListener
                when {
                    s.engine.isRecording -> s.stopRec()
                    prefs.getString("mode", "video") == "photo" -> s.photo()
                    else -> s.startRec()
                }
            }
        }
        controls.addView(shutter, LinearLayout.LayoutParams(dp(86), dp(86)))
        controls.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        val right = FrameLayout(this)
        switchBtn = iconButton(IconView.Kind.SWITCH, 54, Ui062.oval(Color.parseColor("#1A1A1A")), "Trocar câmera") {
            svc?.switchLens()
        }
        right.addView(switchBtn, FrameLayout.LayoutParams(dp(54), dp(54)))
        photoBtn = FrameLayout(this).apply {
            background = Ui062.oval(Ui062.TEXT)
            contentDescription = "Tirar foto"
            isClickable = true
            setOnClickListener { svc?.photo() }
            addView(View(context).apply {
                background = Ui062.oval(Color.TRANSPARENT, Ui062.BG, dp(2))
            }, FrameLayout.LayoutParams(dp(38), dp(38), Gravity.CENTER))
            visibility = View.GONE
        }
        right.addView(photoBtn, FrameLayout.LayoutParams(dp(54), dp(54)))
        controls.addView(right, LinearLayout.LayoutParams(dp(54), dp(54)))
        panel.addView(controls, LinearLayout.LayoutParams(-1, -2))

        bottom.addView(panel, LinearLayout.LayoutParams(-1, -2))
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // ---------- tela de desligado
        offPanel = FrameLayout(this).apply {
            setBackgroundColor(Ui062.BG)
            isClickable = true
            visibility = View.GONE
        }
        val offCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        offCol.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo_062)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = Ui062.oval(Color.BLACK)
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            contentDescription = "062 Fish"
        }, LinearLayout.LayoutParams(dp(130), dp(130)))
        offCol.addView(
            Ui062.text(this, "062 Cam desligado", 22f, Ui062.TEXT, true),
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(18) }
        )
        offCol.addView(
            Ui062.text(this, "Câmera e microfone parados. Não gasta bateria.", 14f, Ui062.MUTED).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) }
        )
        offCol.addView(
            Ui062.text(this, "Versão ${appVersion()}", 12f, Ui062.DIM).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) }
        )
        val bigPower = FrameLayout(this).apply {
            background = Ui062.oval(Ui062.YELLOW)
            contentDescription = "Ligar"
            isClickable = true
            setOnClickListener { powerOn() }
            addView(IconView(context, IconView.Kind.POWER, Ui062.ON_YELLOW), FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))
        }
        offCol.addView(bigPower, LinearLayout.LayoutParams(dp(128), dp(128)).apply { topMargin = dp(40) })
        offCol.addView(
            Ui062.text(this, "Toque para ligar", 15f, Ui062.YELLOW, true),
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) }
        )
        offPanel.addView(offCol, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        val offLinks = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        offLinks.addView(Ui062.text(this, "Ajustes", 14f, Ui062.MUTED, true).apply {
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        offLinks.addView(Ui062.text(this, "Momentos marcados", 14f, Ui062.MUTED, true).apply {
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { startActivity(Intent(this@MainActivity, MarksActivity::class.java)) }
        })
        offLinks.addView(Ui062.text(this, "Meus vídeos", 14f, Ui062.MUTED, true).apply {
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { openGallery() }
        })
        offPanel.addView(offLinks, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(24) })
        root.addView(offPanel, FrameLayout.LayoutParams(-1, -1))

        // ---------- tela escura: parece desligada, mas mostra que o app está funcionando
        darkOverlay = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isClickable = true
            visibility = View.GONE
            setOnClickListener {
                val now = System.currentTimeMillis()
                if (now - lastOverlayTap < 500) hideDark()
                lastOverlayTap = now
            }
        }
        darkBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val darkRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        darkDot = View(this)
        darkRow.addView(darkDot, LinearLayout.LayoutParams(dp(12), dp(12)).apply { marginEnd = dp(10) })
        darkText = Ui062.text(this, "", 16f, Color.parseColor("#2E8A55"), true)
        darkRow.addView(darkText)
        darkBox.addView(darkRow)
        darkHint = Ui062.text(this, "toque duas vezes para voltar", 12f, Color.parseColor("#333333"))
        darkBox.addView(darkHint, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
        darkOverlay.addView(darkBox, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        root.addView(darkOverlay, FrameLayout.LayoutParams(-1, -1))

        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateTransform() }
        setContentView(root)
    }
}
