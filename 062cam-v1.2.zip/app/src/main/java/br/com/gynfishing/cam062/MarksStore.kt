package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Guarda no próprio celular os momentos marcados de cada vídeo.

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object MarksStore {
    data class Entry(val uri: String, val name: String, val savedAt: Long, val marks: List<Long>)

    private const val KEY = "marks_json"
    private const val MAX_ENTRIES = 200

    fun add(ctx: Context, uri: String, name: String, marks: List<Long>) {
        if (marks.isEmpty()) return
        val list = load(ctx).toMutableList()
        list.add(0, Entry(uri, name, System.currentTimeMillis(), marks))
        save(ctx, list.take(MAX_ENTRIES))
    }

    fun remove(ctx: Context, uri: String) {
        save(ctx, load(ctx).filter { it.uri != uri })
    }

    fun load(ctx: Context): List<Entry> {
        val raw = ctx.getSharedPreferences(Prefs.FILE, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val m = o.getJSONArray("marks")
                Entry(
                    o.getString("uri"), o.getString("name"), o.getLong("at"),
                    (0 until m.length()).map { m.getLong(it) }
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun save(ctx: Context, list: List<Entry>) {
        val arr = JSONArray()
        for (e in list) {
            arr.put(JSONObject().apply {
                put("uri", e.uri)
                put("name", e.name)
                put("at", e.savedAt)
                put("marks", JSONArray(e.marks))
            })
        }
        ctx.getSharedPreferences(Prefs.FILE, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format("%02d:%02d", s / 60, s % 60)
    }
}
