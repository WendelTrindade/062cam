package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Meus vídeos: lista os vídeos da pasta Filmes/062Cam, com Assistir e Editar.

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class VideosActivity : Activity() {

    private data class Video(val uri: Uri, val name: String, val dateSec: Long, val durationMs: Long)

    private lateinit var list: LinearLayout
    private val main = Handler(Looper.getMainLooper())
    private var asked = false

    private fun dp(v: Int) = Ui062.dp(this, v)

    private fun readPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui062.BG
        window.navigationBarColor = Ui062.BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui062.BG)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(12))
        }
        val back = FrameLayout(this).apply {
            background = Ui062.shape(context, Ui062.CARD, 12)
            contentDescription = "Voltar"
            isClickable = true
            setOnClickListener { finish() }
            addView(IconView(context, IconView.Kind.BACK), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        }
        header.addView(back, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(12) })
        header.addView(Ui062.text(this, "Meus vídeos", 22f, Ui062.TEXT, true))
        root.addView(header)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(24))
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (!asked && checkSelfPermission(readPermission()) != PackageManager.PERMISSION_GRANTED) {
            asked = true
            requestPermissions(arrayOf(readPermission()), 3)
        }
        load()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        load()
    }

    private fun load() {
        Thread {
            val found = mutableListOf<Video>()
            try {
                contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(
                        MediaStore.MediaColumns._ID,
                        MediaStore.MediaColumns.DISPLAY_NAME,
                        MediaStore.MediaColumns.DATE_ADDED,
                        MediaStore.Video.VideoColumns.DURATION
                    ),
                    "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                    arrayOf("%${CameraEngine.FOLDER}%"),
                    "${MediaStore.MediaColumns.DATE_ADDED} DESC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        found.add(
                            Video(
                                ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(0)),
                                c.getString(1) ?: "",
                                c.getLong(2),
                                c.getLong(3)
                            )
                        )
                    }
                }
            } catch (_: Exception) {
            }
            main.post { if (!isFinishing) show(found) }
        }.start()
    }

    private fun show(videos: List<Video>) {
        list.removeAllViews()
        if (videos.isEmpty()) {
            list.addView(
                Ui062.text(
                    this,
                    "Nenhum vídeo ainda.\n\nOs vídeos gravados pelo 062 Cam aparecem aqui. Toque em “Editar” para dar zoom, deixar lento ou acelerar um trecho.",
                    15f, Ui062.MUTED
                ).apply { setLineSpacing(0f, 1.2f) },
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) }
            )
            return
        }
        val df = SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", Locale("pt", "BR"))
        for (v in videos) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = Ui062.shape(context, Ui062.CARD, 14)
                setPadding(dp(10), dp(10), dp(12), dp(10))
            }
            val thumb = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = Ui062.shape(context, Color.parseColor("#2A2A2A"), 10)
                outlineProvider = ViewOutlineProvider.BACKGROUND
                clipToOutline = true
            }
            row.addView(thumb, LinearLayout.LayoutParams(dp(64), dp(84)).apply { marginEnd = dp(12) })
            Thread {
                val bmp = try {
                    contentResolver.loadThumbnail(v.uri, Size(200, 260), null)
                } catch (_: Exception) {
                    null
                }
                main.post { if (bmp != null) thumb.setImageBitmap(bmp) }
            }.start()

            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(Ui062.text(this, df.format(Date(v.dateSec * 1000)), 15f, Ui062.TEXT, true))
            val kind = when {
                v.name.contains("editado") -> " · editado"
                v.name.contains("clipe") -> " · clipe"
                else -> ""
            }
            col.addView(
                Ui062.text(this, TimeFmt.mmss(v.durationMs) + kind, 12f, Ui062.DIM),
                LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) }
            )
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.addView(Ui062.text(this, "Assistir", 13f, Ui062.TEXT, true).apply {
                gravity = Gravity.CENTER
                background = Ui062.shape(context, Color.TRANSPARENT, 9, Color.parseColor("#3A3A3A"), 1)
                setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { watch(v.uri) }
            }, LinearLayout.LayoutParams(-2, dp(36)).apply { marginEnd = dp(8) })
            buttons.addView(Ui062.text(this, "Editar", 13f, Ui062.ON_YELLOW, true).apply {
                gravity = Gravity.CENTER
                background = Ui062.shape(context, Ui062.YELLOW, 9)
                setPadding(dp(18), 0, dp(18), 0)
                setOnClickListener {
                    startActivity(Intent(this@VideosActivity, EditorActivity::class.java).putExtra("uri", v.uri.toString()))
                }
            }, LinearLayout.LayoutParams(-2, dp(36)))
            col.addView(buttons, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }
    }

    private fun watch(uri: Uri) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: Exception) {
            Toast.makeText(this, "Abra a galeria do celular: Filmes/062Cam", Toast.LENGTH_SHORT).show()
        }
    }
}
