package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Tela de primeiro uso: explica os comandos e libera câmera, microfone e bateria.

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class WelcomeActivity : Activity() {

    private val prefs by lazy { getSharedPreferences(Prefs.FILE, MODE_PRIVATE) }
    private lateinit var checkPerm: View
    private lateinit var checkBattery: View
    private lateinit var button: TextView
    private var batteryAsked = false

    private fun dp(v: Int) = Ui062.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui062.BG
        window.navigationBarColor = Ui062.BG
        build()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun refresh() {
        val perm = Ui062.hasPermissions(this)
        val bat = Ui062.batteryFree(this)
        paintCheck(checkPerm, perm)
        paintCheck(checkBattery, bat)
        button.text = when {
            !perm -> "Autorizar câmera e microfone"
            !bat && !batteryAsked -> "Liberar bateria"
            else -> "Começar"
        }
    }

    private fun onButton() {
        when {
            !Ui062.hasPermissions(this) -> requestPermissions(Ui062.neededPermissions(), 1)
            !Ui062.batteryFree(this) && !batteryAsked -> {
                batteryAsked = true
                Ui062.askBatteryExemption(this)
            }
            else -> {
                prefs.edit().putBoolean("welcomed", true).apply()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }
    }

    private fun paintCheck(v: View, ok: Boolean) {
        v.background = if (ok) Ui062.oval(Ui062.GREEN) else Ui062.oval(Color.TRANSPARENT, Ui062.DIM, dp(2))
        (v as? TextView)?.text = if (ok) "✓" else ""
    }

    private fun build() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui062.BG)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
        }
        scroll.addView(root)

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo_062)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = Ui062.oval(Color.BLACK)
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            contentDescription = "062 Fish"
        }
        root.addView(logo, LinearLayout.LayoutParams(dp(150), dp(150)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        root.addView(
            Ui062.text(this, "CAM", 22f, Ui062.YELLOW, true).apply { letterSpacing = 0.15f },
            LinearLayout.LayoutParams(-2, -2).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(6)
            }
        )

        root.addView(
            Ui062.text(this, "Grave sem tocar no celular", 28f, Ui062.TEXT, true),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) }
        )
        root.addView(
            Ui062.text(this, "Apoie o celular, bloqueie a tela e comande pela voz. Tudo funciona sem internet.", 15f, Ui062.MUTED)
                .apply { setLineSpacing(0f, 1.25f) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        )

        root.addView(command("“Gravar”", "Começa o vídeo, com a pré-gravação", 0), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })
        root.addView(command("“Parar”", "Encerra e salva na galeria", 1), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        root.addView(command("“Foto”", "Tira foto, até no meio do vídeo", 2), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        root.addView(
            Ui062.text(this, "Também: “marca” guarda o momento durante o vídeo, e “salva isso” salva os últimos segundos sem estar gravando.", 13f, Ui062.DIM)
                .apply { setLineSpacing(0f, 1.2f) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        )

        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui062.shape(context, Color.TRANSPARENT, 16, Color.parseColor("#2A2A2A"), 1)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        box.addView(Ui062.text(this, "Para gravar com a tela bloqueada", 13f, Ui062.TEXT, true))
        checkPerm = checkRow(box, "Câmera e microfone autorizados")
        checkBattery = checkRow(box, "Bateria sem restrições")
        root.addView(box, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(24)
            bottomMargin = dp(16)
        })

        button = Ui062.text(this, "Começar", 16f, Ui062.ON_YELLOW, true).apply {
            gravity = Gravity.CENTER
            background = Ui062.shape(context, Ui062.YELLOW, 16)
            isClickable = true
            setOnClickListener { onButton() }
        }
        root.addView(button, LinearLayout.LayoutParams(-1, dp(56)))

        setContentView(scroll)
    }

    private fun checkRow(parent: LinearLayout, label: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val dot = Ui062.text(this, "", 12f, Color.parseColor("#062611"), true).apply { gravity = Gravity.CENTER }
        row.addView(dot, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(10) })
        row.addView(Ui062.text(this, label, 13f, Ui062.MUTED))
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        return dot
    }

    private fun command(title: String, sub: String, kind: Int): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui062.shape(context, Ui062.CARD, 16)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val icon = FrameLayout(this)
        when (kind) {
            0 -> {
                icon.background = Ui062.shape(this, Color.parseColor("#29FF3B30"), 12)
                icon.addView(View(this).apply { background = Ui062.oval(Ui062.RED) }, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
            }
            1 -> {
                icon.background = Ui062.shape(this, Color.parseColor("#1AF2F4F6"), 12)
                icon.addView(View(this).apply { background = Ui062.shape(context, Ui062.TEXT, 3) }, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.CENTER))
            }
            else -> {
                icon.background = Ui062.shape(this, Color.parseColor("#29FBC403"), 12)
                icon.addView(IconView(this, IconView.Kind.CAMERA, Ui062.YELLOW), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            }
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(14) })
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(Ui062.text(this, title, 18f, Ui062.TEXT, true))
        texts.addView(Ui062.text(this, sub, 13f, Ui062.MUTED), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        return row
    }
}
