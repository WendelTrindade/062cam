package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Peças da tela do editor: a linha do tempo (faixa de imagens com o corte,
// faixa de zoom e faixa de velocidade) e o quadro amarelo do zoom na imagem.

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

@SuppressLint("ViewConstructor")
class TimelineView(ctx: Context, private val model: EditorModel) : View(ctx) {

    interface Listener {
        fun onSeek(ms: Long)
        fun onSelect(block: Block?)
        fun onEditing()
        fun onEdited()
    }

    var listener: Listener? = null
    var thumbs: List<Bitmap?> = emptyList()
        set(v) {
            field = v
            invalidate()
        }
    var playheadMs = 0L
        set(v) {
            if (field != v) {
                field = v
                invalidate()
            }
        }

    private fun dp(v: Float) = Ui062.dpf(context, v)

    private val pad = dp(14f)
    private val stripTop = dp(4f)
    private val stripH = dp(54f)
    private val zoomTop get() = stripTop + stripH + dp(10f)
    private val trackH = dp(30f)
    private val speedTop get() = zoomTop + trackH + dp(6f)
    private val totalH = (dp(4f) + dp(54f) + dp(10f) + dp(30f) + dp(6f) + dp(30f) + dp(4f)).toInt()

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = dp(11f)
        typeface = Ui062.BOLD
        textAlign = Paint.Align.CENTER
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = dp(11f)
        color = Color.parseColor("#6F7A84")
    }
    private val speedColor = Color.parseColor("#4FC3F7")
    private val speedText = Color.parseColor("#04263A")

    private enum class Drag { NONE, SEEK, TRIM_START, TRIM_END, MOVE, RESIZE_L, RESIZE_R }

    private var drag = Drag.NONE
    private var dragBlock: Block? = null
    private var grabOffsetMs = 0L

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), totalH)
    }

    private val usable get() = (width - 2 * pad).coerceAtLeast(1f)
    private fun x(ms: Long): Float = pad + usable * (ms.toFloat() / model.durationMs.coerceAtLeast(1))
    private fun ms(x: Float): Long =
        (((x - pad) / usable) * model.durationMs).toLong().coerceIn(0L, model.durationMs)

    override fun onDraw(c: Canvas) {
        // ---------- faixa de imagens
        val left = pad
        val right = width - pad
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#1E252C")
        c.drawRoundRect(RectF(left, stripTop, right, stripTop + stripH), dp(8f), dp(8f), paint)
        if (thumbs.isNotEmpty()) {
            val cellW = (right - left) / thumbs.size
            c.save()
            c.clipRect(left, stripTop, right, stripTop + stripH)
            thumbs.forEachIndexed { i, b ->
                if (b != null) {
                    val dst = RectF(left + i * cellW, stripTop, left + (i + 1) * cellW - dp(1f), stripTop + stripH)
                    c.drawBitmap(b, null, dst, null)
                }
            }
            c.restore()
        }
        // fora do corte fica escuro
        paint.color = Color.argb(185, 0, 0, 0)
        val ts = x(model.trimStart)
        val te = x(model.trimEnd)
        if (ts > left) c.drawRect(left, stripTop, ts, stripTop + stripH, paint)
        if (te < right) c.drawRect(te, stripTop, right, stripTop + stripH, paint)
        // alças amarelas do corte
        paint.color = Ui062.YELLOW
        val hw = dp(10f)
        c.drawRoundRect(RectF(ts - hw, stripTop, ts, stripTop + stripH), dp(4f), dp(4f), paint)
        c.drawRoundRect(RectF(te, stripTop, te + hw, stripTop + stripH), dp(4f), dp(4f), paint)
        c.drawRect(ts, stripTop, te, stripTop + dp(3f), paint)
        c.drawRect(ts, stripTop + stripH - dp(3f), te, stripTop + stripH, paint)
        paint.color = Ui062.ON_YELLOW
        c.drawRect(ts - hw / 2 - dp(1f), stripTop + stripH / 2 - dp(8f), ts - hw / 2 + dp(1f), stripTop + stripH / 2 + dp(8f), paint)
        c.drawRect(te + hw / 2 - dp(1f), stripTop + stripH / 2 - dp(8f), te + hw / 2 + dp(1f), stripTop + stripH / 2 + dp(8f), paint)

        // ---------- faixas de zoom e velocidade
        drawTrack(c, zoomTop, "Zoom", model.zooms)
        drawTrack(c, speedTop, "Velocidade", model.speeds)

        // ---------- linha branca da posição atual
        paint.color = Color.WHITE
        val px = x(playheadMs)
        c.drawRect(px - dp(1f), stripTop - dp(2f), px + dp(1f), speedTop + trackH + dp(2f), paint)
    }

    private fun drawTrack(c: Canvas, top: Float, label: String, blocks: List<Block>) {
        paint.style = Paint.Style.FILL
        paint.color = Ui062.CARD
        c.drawRoundRect(RectF(pad, top, width - pad, top + trackH), dp(6f), dp(6f), paint)
        c.drawText(label, pad + dp(8f), top + trackH / 2 + dp(4f), labelPaint)
        for (b in blocks) {
            val r = RectF(x(b.startMs), top + dp(3f), x(b.endMs), top + trackH - dp(3f))
            val isZoom = b is ZoomBlock
            paint.style = Paint.Style.FILL
            paint.color = if (isZoom) Ui062.YELLOW else speedColor
            c.drawRoundRect(r, dp(5f), dp(5f), paint)
            if (b === model.selected) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = dp(2f)
                paint.color = Color.WHITE
                c.drawRoundRect(r, dp(5f), dp(5f), paint)
                paint.style = Paint.Style.FILL
                // pontas para arrastar
                paint.color = Color.WHITE
                c.drawRoundRect(RectF(r.left, r.top, r.left + dp(5f), r.bottom), dp(2f), dp(2f), paint)
                c.drawRoundRect(RectF(r.right - dp(5f), r.top, r.right, r.bottom), dp(2f), dp(2f), paint)
            }
            val txt = if (b is ZoomBlock) TimeFmt.factor(b.level) else TimeFmt.factor((b as SpeedBlock).speed)
            if (r.width() > textPaint.measureText(txt) + dp(8f)) {
                textPaint.color = if (isZoom) Ui062.ON_YELLOW else speedText
                c.drawText(txt, r.centerX(), r.centerY() + dp(4f), textPaint)
            }
        }
    }

    private fun hitBlock(blocks: List<Block>, x: Float): Block? {
        val slop = dp(10f)
        return blocks.firstOrNull { x >= x(it.startMs) - slop && x <= x(it.endMs) + slop }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val tx = e.x
                val ty = e.y
                drag = Drag.NONE
                dragBlock = null
                when {
                    ty <= stripTop + stripH + dp(4f) -> {
                        val ts = x(model.trimStart)
                        val te = x(model.trimEnd)
                        drag = when {
                            abs(tx - (ts - dp(5f))) < dp(22f) && abs(tx - ts) <= abs(tx - te) -> Drag.TRIM_START
                            abs(tx - (te + dp(5f))) < dp(22f) -> Drag.TRIM_END
                            else -> Drag.SEEK
                        }
                        if (drag == Drag.SEEK) listener?.onSeek(ms(tx))
                    }
                    else -> {
                        val track: List<Block> = if (ty < speedTop - dp(3f)) model.zooms else model.speeds
                        val b = hitBlock(track, tx)
                        if (b == null) {
                            model.selected = null
                            listener?.onSelect(null)
                            drag = Drag.SEEK
                            listener?.onSeek(ms(tx))
                        } else {
                            if (model.selected !== b) {
                                model.selected = b
                                listener?.onSelect(b)
                            }
                            dragBlock = b
                            val edge = dp(16f)
                            drag = when {
                                abs(tx - x(b.startMs)) < edge -> Drag.RESIZE_L
                                abs(tx - x(b.endMs)) < edge -> Drag.RESIZE_R
                                else -> Drag.MOVE
                            }
                            grabOffsetMs = ms(tx) - b.startMs
                        }
                    }
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val t = ms(e.x)
                val b = dragBlock
                when (drag) {
                    Drag.SEEK -> listener?.onSeek(t)
                    Drag.TRIM_START -> {
                        model.trimStart = t.coerceIn(0L, model.trimEnd - EditorModel.MIN_TRIM_MS)
                        listener?.onSeek(model.trimStart)
                        listener?.onEditing()
                    }
                    Drag.TRIM_END -> {
                        model.trimEnd = t.coerceIn(model.trimStart + EditorModel.MIN_TRIM_MS, model.durationMs)
                        listener?.onSeek(model.trimEnd)
                        listener?.onEditing()
                    }
                    Drag.RESIZE_L -> if (b != null) {
                        val (lo, _) = model.limitsFor(b)
                        b.startMs = t.coerceIn(lo, b.endMs - EditorModel.MIN_BLOCK_MS)
                        listener?.onSeek(b.startMs)
                        listener?.onEditing()
                    }
                    Drag.RESIZE_R -> if (b != null) {
                        val (_, hi) = model.limitsFor(b)
                        b.endMs = t.coerceIn(b.startMs + EditorModel.MIN_BLOCK_MS, hi)
                        listener?.onSeek(b.endMs)
                        listener?.onEditing()
                    }
                    Drag.MOVE -> if (b != null) {
                        val (lo, hi) = model.limitsFor(b)
                        val len = b.lengthMs
                        val start = (t - grabOffsetMs).coerceIn(lo, (hi - len).coerceAtLeast(lo))
                        b.startMs = start
                        b.endMs = start + len
                        listener?.onSeek(b.startMs)
                        listener?.onEditing()
                    }
                    Drag.NONE -> {}
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (drag != Drag.SEEK && drag != Drag.NONE) listener?.onEdited()
                drag = Drag.NONE
                dragBlock = null
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Quadro amarelo sobre a imagem: arraste para escolher o ponto do zoom. */
@SuppressLint("ViewConstructor")
class ZoomFrameView(ctx: Context) : View(ctx) {

    var block: ZoomBlock? = null
        set(v) {
            field = v
            visibility = if (v == null) GONE else VISIBLE
            invalidate()
        }
    var onMoved: (() -> Unit)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = Ui062.dpf(ctx, 12f)
        typeface = Ui062.BOLD
        color = Ui062.ON_YELLOW
    }
    private var lastX = 0f
    private var lastY = 0f

    private fun frame(): RectF? {
        val b = block ?: return null
        val w = width.toFloat()
        val h = height.toFloat()
        val fw = w / b.level
        val fh = h / b.level
        val cu = EditorModel.clampCenter(b.cu, b.level)
        val cv = EditorModel.clampCenter(b.cv, b.level)
        val l = cu * w - fw / 2
        val t = cv * h - fh / 2
        return RectF(l, t, l + fw, t + fh)
    }

    override fun onDraw(c: Canvas) {
        val r = frame() ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(140, 5, 5, 5)
        c.drawRect(0f, 0f, w, r.top, paint)
        c.drawRect(0f, r.bottom, w, h, paint)
        c.drawRect(0f, r.top, r.left, r.bottom, paint)
        c.drawRect(r.right, r.top, w, r.bottom, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = Ui062.dpf(context, 2f)
        paint.color = Ui062.YELLOW
        c.drawRect(r, paint)
        c.drawCircle(r.centerX(), r.centerY(), Ui062.dpf(context, 9f), paint)
        paint.style = Paint.Style.FILL
        val d = Ui062.dpf(context, 5f)
        for ((px, py) in listOf(r.left to r.top, r.right to r.top, r.left to r.bottom, r.right to r.bottom)) {
            c.drawCircle(px, py, d, paint)
        }
        val txt = "Zoom ${TimeFmt.factor(block!!.level)} aqui · arraste"
        val tw = label.measureText(txt) + Ui062.dpf(context, 14f)
        val th = Ui062.dpf(context, 22f)
        var tx = r.left
        var ty = r.top - th - Ui062.dpf(context, 4f)
        if (ty < 0f) ty = r.bottom + Ui062.dpf(context, 4f)
        if (tx + tw > w) tx = w - tw
        c.drawRoundRect(RectF(tx, ty, tx + tw, ty + th), Ui062.dpf(context, 6f), Ui062.dpf(context, 6f), paint)
        c.drawText(txt, tx + Ui062.dpf(context, 7f), ty + th - Ui062.dpf(context, 7f), label)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val b = block ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = e.x
                lastY = e.y
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                b.cu = EditorModel.clampCenter(b.cu + (e.x - lastX) / width.coerceAtLeast(1), b.level)
                b.cv = EditorModel.clampCenter(b.cv + (e.y - lastY) / height.coerceAtLeast(1), b.level)
                lastX = e.x
                lastY = e.y
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                onMoved?.invoke()
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}
