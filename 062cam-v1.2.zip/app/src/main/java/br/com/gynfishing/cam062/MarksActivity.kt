package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Lista dos vídeos com momentos marcados. Tocar num horário abre o vídeo ali.

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MarksActivity : Activity() {

    private lateinit var list: LinearLayout

    private fun dp(v: Int) = Ui062.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui062.BG
        window.navigationBarColor = Ui062.BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui062.BG)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(12))
        }
        val back = FrameLayout(this).apply {
            background = Ui062.shape(context, Ui062.CARD, 12)
            contentDescription = "Voltar"
            isClickable = true
            setOnClickListener { finish() }
            addView(IconView(context, IconView.Kind.BACK), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        }
        header.addView(back, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(12) })
        header.addView(Ui062.text(this, "Momentos marcados", 22f, Ui062.TEXT, true))
        root.addView(header)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(24))
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        fill()
    }

    private fun fill() {
        list.removeAllViews()
        val entries = MarksStore.load(this)
        if (entries.isEmpty()) {
            list.addView(
                Ui062.text(
                    this,
                    "Nenhum momento marcado ainda.\n\nDurante a gravação, diga “marca” ou toque em “Marcar momento”. Depois, toque no horário aqui para ver o vídeo direto naquele ponto.",
                    15f, Ui062.MUTED
                ).apply { setLineSpacing(0f, 1.2f) },
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) }
            )
            return
        }
        val df = SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", Locale("pt", "BR"))
        for (e in entries) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = Ui062.shape(context, Ui062.CARD, 14)
                setPadding(dp(16), dp(14), dp(16), dp(14))
            }
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(Ui062.text(this, df.format(Date(e.savedAt)), 15f, Ui062.TEXT, true))
            texts.addView(
                Ui062.text(this, "${e.marks.size} momento(s) · ${e.name}", 12f, Ui062.DIM),
                LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) }
            )
            top.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            top.addView(Ui062.text(this, "Remover", 13f, Ui062.DIM).apply {
                setPadding(dp(8), dp(8), 0, dp(8))
                setOnClickListener {
                    MarksStore.remove(this@MarksActivity, e.uri)
                    fill()
                }
            })
            card.addView(top)

            val chipsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
            val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (ms in e.marks) {
                chips.addView(
                    Ui062.text(this, "▶  ${MarksStore.fmt(ms)}", 14f, Ui062.ON_YELLOW, true).apply {
                        gravity = Gravity.CENTER
                        background = Ui062.shape(context, Ui062.YELLOW, 10)
                        setPadding(dp(14), 0, dp(14), 0)
                        setOnClickListener { open(e, ms) }
                    },
                    LinearLayout.LayoutParams(-2, dp(40)).apply { marginEnd = dp(8) }
                )
            }
            chipsScroll.addView(chips)
            card.addView(chipsScroll, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }
        list.addView(
            Ui062.text(this, "O vídeo abre 3 segundos antes da marca.", 12f, Color.parseColor("#6F7A84")).apply {
                gravity = Gravity.CENTER
            },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        )
    }

    private fun open(e: MarksStore.Entry, ms: Long) {
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra("uri", e.uri)
                .putExtra("ms", ms)
                .putExtra("marks", e.marks.toLongArray())
        )
    }
}
