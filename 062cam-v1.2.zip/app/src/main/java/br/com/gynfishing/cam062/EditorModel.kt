package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Guarda as edições de um vídeo: corte do começo e do fim, trechos com zoom
// e trechos com velocidade diferente. Zoom e velocidade ficam em faixas
// separadas, então podem ser usados juntos no mesmo trecho.

open class Block(var startMs: Long, var endMs: Long) {
    val lengthMs: Long get() = endMs - startMs
}

class ZoomBlock(startMs: Long, endMs: Long, var level: Float = 2f, var cu: Float = 0.5f, var cv: Float = 0.5f) :
    Block(startMs, endMs)

class SpeedBlock(startMs: Long, endMs: Long, var speed: Float) : Block(startMs, endMs)

/** Força do zoom num instante: z = quanto aproxima, (cu, cv) = ponto da imagem (0 a 1). */
data class ZoomState(val z: Float, val cu: Float, val cv: Float)

/** Cópia fixa dos trechos de zoom, usada enquanto o vídeo é gerado. */
class ZoomCurve(blocks: List<ZoomBlock>) {
    private val list = blocks.map { ZoomBlock(it.startMs, it.endMs, it.level, it.cu, it.cv) }.sortedBy { it.startMs }

    fun zoomAt(t: Long): ZoomState = EditorModel.zoomFor(list, t)
}

class EditorModel(val durationMs: Long) {

    class Segment(val startMs: Long, val endMs: Long, val speed: Float)

    var trimStart = 0L
    var trimEnd = durationMs
    var mute = false
    val zooms = mutableListOf<ZoomBlock>()
    val speeds = mutableListOf<SpeedBlock>()
    var selected: Block? = null

    companion object {
        const val MIN_BLOCK_MS = 300L
        const val MIN_TRIM_MS = 500L

        fun clampCenter(c: Float, z: Float): Float {
            val half = 0.5f / z.coerceAtLeast(1f)
            return c.coerceIn(half, 1f - half)
        }

        /** Zoom com entrada e saída suaves (sem pulo). */
        fun zoomFor(list: List<ZoomBlock>, t: Long): ZoomState {
            val b = list.firstOrNull { t >= it.startMs && t <= it.endMs } ?: return ZoomState(1f, 0.5f, 0.5f)
            val len = b.lengthMs.toFloat()
            val ramp = minOf(400f, len / 3f)
            val f = when {
                ramp <= 0f -> 1f
                t - b.startMs < ramp -> (t - b.startMs) / ramp
                b.endMs - t < ramp -> (b.endMs - t) / ramp
                else -> 1f
            }.coerceIn(0f, 1f)
            val e = f * f * (3f - 2f * f)
            val z = 1f + (b.level - 1f) * e
            return ZoomState(z, clampCenter(b.cu, z), clampCenter(b.cv, z))
        }
    }

    fun hasChanges(): Boolean =
        trimStart > 0 || trimEnd < durationMs || mute || zooms.isNotEmpty() || speeds.isNotEmpty()

    fun zoomAt(t: Long): ZoomState = zoomFor(zooms, t)

    fun speedAt(t: Long): Float = speeds.firstOrNull { t >= it.startMs && t < it.endMs }?.speed ?: 1f

    fun trackOf(b: Block): MutableList<out Block> = if (b is ZoomBlock) zooms else speeds

    /** Limites que um trecho pode ocupar sem invadir os vizinhos da mesma faixa. */
    fun limitsFor(b: Block): Pair<Long, Long> {
        val others = trackOf(b).filter { it !== b }
        val lo = others.filter { it.endMs <= b.startMs }.maxOfOrNull { it.endMs } ?: 0L
        val hi = others.filter { it.startMs >= b.endMs }.minOfOrNull { it.startMs } ?: durationMs
        return lo to hi
    }

    /** Espaço livre para criar um trecho novo começando em t (até 3 s). */
    fun freeEnd(track: List<Block>, t: Long): Long {
        val next = track.filter { it.startMs > t }.minOfOrNull { it.startMs } ?: durationMs
        return minOf(t + 3000, next, trimEnd)
    }

    fun remove(b: Block) {
        if (b is ZoomBlock) zooms.remove(b) else if (b is SpeedBlock) speeds.remove(b)
        if (selected === b) selected = null
    }

    /** Divide o vídeo (dentro do corte) em pedaços de velocidade única. */
    fun segments(): List<Segment> {
        val cuts = sortedSetOf(trimStart, trimEnd)
        for (s in speeds) {
            if (s.startMs > trimStart && s.startMs < trimEnd) cuts.add(s.startMs)
            if (s.endMs > trimStart && s.endMs < trimEnd) cuts.add(s.endMs)
        }
        val pts = cuts.toList()
        val out = mutableListOf<Segment>()
        for (i in 0 until pts.size - 1) {
            val a = pts[i]
            val b = pts[i + 1]
            if (b - a < 60) continue
            val sp = speedAt((a + b) / 2)
            val last = out.lastOrNull()
            if (last != null && last.speed == sp && last.endMs == a) {
                out[out.size - 1] = Segment(last.startMs, b, sp)
            } else {
                out.add(Segment(a, b, sp))
            }
        }
        return out
    }

    fun outputDurationMs(): Long = segments().sumOf { ((it.endMs - it.startMs) / it.speed).toLong() }

    fun outputLengthOf(b: SpeedBlock): Long = (b.lengthMs / b.speed).toLong()
}

object TimeFmt {
    fun mmss(ms: Long): String {
        val s = (ms.coerceAtLeast(0)) / 1000
        return String.format("%02d:%02d", s / 60, s % 60)
    }

    fun secs(ms: Long): String {
        val tenths = (ms.coerceAtLeast(0) + 50) / 100
        return if (tenths % 10 == 0L) "${tenths / 10} s" else "${tenths / 10},${tenths % 10} s"
    }

    fun factor(f: Float): String = when (f) {
        0.25f -> "0,25×"
        0.5f -> "0,5×"
        1.5f -> "1,5×"
        else -> "${f.toInt()}×"
    }
}
