package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Toca o vídeo já no momento marcado, com atalhos para as outras marcas.

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView

class PlayerActivity : Activity() {

    private lateinit var video: VideoView

    private fun dp(v: Int) = Ui062.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val uri = Uri.parse(intent.getStringExtra("uri") ?: run { finish(); return })
        val startMs = intent.getLongExtra("ms", 0L)
        val marks = intent.getLongArrayExtra("marks") ?: longArrayOf(startMs)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        val box = FrameLayout(this)
        video = VideoView(this)
        box.addView(video, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        root.addView(box, LinearLayout.LayoutParams(-1, 0, 1f))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui062.BG)
            setPadding(dp(16), dp(12), dp(16), dp(20))
        }
        bar.addView(Ui062.text(this, "Ir para a marca", 12f, Ui062.DIM, true).apply { letterSpacing = 0.06f })
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (ms in marks) {
            chips.addView(
                Ui062.text(this, MarksStore.fmt(ms), 14f, Ui062.ON_YELLOW, true).apply {
                    gravity = Gravity.CENTER
                    background = Ui062.shape(context, Ui062.YELLOW, 10)
                    setPadding(dp(14), 0, dp(14), 0)
                    setOnClickListener { jump(ms) }
                },
                LinearLayout.LayoutParams(-2, dp(40)).apply { marginEnd = dp(8) }
            )
        }
        scroll.addView(chips)
        bar.addView(scroll, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(bar)
        setContentView(root)

        val mc = MediaController(this)
        mc.setAnchorView(video)
        video.setMediaController(mc)
        video.setVideoURI(uri)
        video.setOnPreparedListener {
            jump(startMs)
            video.start()
        }
        video.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "Não consegui abrir este vídeo (pode ter sido apagado)", Toast.LENGTH_LONG).show()
            true
        }
    }

    private fun jump(ms: Long) {
        video.seekTo((ms - 3000).coerceAtLeast(0).toInt())
        if (!video.isPlaying) video.start()
    }
}
