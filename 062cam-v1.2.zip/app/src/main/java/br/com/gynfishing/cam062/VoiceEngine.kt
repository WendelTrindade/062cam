package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Escuta o microfone sem parar. O mesmo som vai para o vídeo e para o
// reconhecimento de voz offline (Vosk, português), que procura os comandos
// "gravar", "parar", "foto", "marca" e "salva isso" (com uma palavra de
// ativação opcional na frente, ex.: "câmera gravar"). Nada vai para a internet.

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.AssetManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream

class VoiceEngine(
    private val ctx: Context,
    private val engine: CameraEngine,
    private val onCommand: (String) -> Unit,
    private val onStatus: (String) -> Unit
) {
    companion object {
        const val READY = "pronto"
        private const val MODEL_VERSION = "pronto-v1"
        private val PHRASES = listOf(
            "gravar", "grava", "parar", "pare", "foto", "tirar foto",
            "marca", "marcar", "salva", "salvar", "salva isso"
        )

        /** Certeza mínima (0 a 1) para aceitar um comando de voz. */
        private const val MIN_CONFIDENCE = 0.85

        fun buildGrammar(prefix: String): String {
            val arr = JSONArray()
            for (ph in PHRASES) arr.put(if (prefix.isBlank()) ph else "$prefix $ph")
            arr.put("[unk]")
            return arr.toString()
        }
    }

    /** Palavra que precisa vir antes do comando ("" = nenhuma). */
    @Volatile var prefix = ""
        private set
    @Volatile private var grammarDirty = false

    fun setPrefix(p: String) {
        prefix = p.trim().lowercase()
        grammarDirty = true
    }

    @Volatile private var running = false
    private var thread: Thread? = null
    @Volatile private var recognizer: Recognizer? = null
    private var model: Model? = null
    private var lastCommandAt = 0L

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "microfone").apply { start() }
        Thread({ loadModel() }, "modelo-voz").start()
    }

    fun stop() {
        running = false
        try {
            thread?.join(1500)
        } catch (_: Exception) {
        }
        thread = null
        try {
            recognizer?.close()
        } catch (_: Exception) {
        }
        recognizer = null
        try {
            model?.close()
        } catch (_: Exception) {
        }
        model = null
    }

    private fun loadModel() {
        try {
            val dir = File(ctx.filesDir, "model-pt")
            val mark = File(dir, MODEL_VERSION)
            if (!mark.exists()) {
                onStatus("Preparando o reconhecimento de voz (só na primeira vez)...")
                dir.deleteRecursively()
                copyAssets(ctx.assets, "model-pt", dir)
                mark.writeText("ok")
            }
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            val m = Model(dir.absolutePath)
            model = m
            recognizer = Recognizer(m, 16000f, buildGrammar(prefix)).apply { setWords(true) }
            grammarDirty = false
            onStatus(READY)
        } catch (e: Throwable) {
            onStatus("Erro no reconhecimento de voz: ${e.message}")
        }
    }

    private fun copyAssets(am: AssetManager, src: String, dst: File) {
        val list = am.list(src) ?: emptyArray()
        if (list.isEmpty()) {
            dst.parentFile?.mkdirs()
            am.open(src).use { input -> FileOutputStream(dst).use { input.copyTo(it) } }
        } else {
            dst.mkdirs()
            for (name in list) copyAssets(am, "$src/$name", File(dst, name))
        }
    }

    @SuppressLint("MissingPermission")
    private fun loop() {
        val rate = CameraEngine.SAMPLE_RATE
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, rate) * 2
            )
        } catch (e: Exception) {
            onStatus("Microfone indisponível: ${e.message}")
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            onStatus("Microfone indisponível (outro app pode estar usando)")
            rec.release()
            return
        }
        rec.startRecording()

        val chunk = rate / 10 // 100 ms de som por vez
        val buf = ShortArray(chunk)
        val down = ShortArray(chunk / 3)
        var nextPts = 0L

        while (running) {
            val n = rec.read(buf, 0, chunk)
            if (n <= 0) continue

            // Marca de tempo do som, no mesmo relógio da câmera
            val dur = n * 1_000_000L / rate
            var pts = engine.nowUs() - dur
            if (pts < nextPts) pts = nextPts
            nextPts = pts + dur
            engine.feedAudio(buf, n, pts)

            // Troca a lista de comandos se a palavra de ativação mudou
            val m0 = model
            if (grammarDirty && m0 != null) {
                grammarDirty = false
                try {
                    val old = recognizer
                    recognizer = Recognizer(m0, 16000f, buildGrammar(prefix)).apply { setWords(true) }
                    old?.close()
                } catch (_: Exception) {
                }
            }

            // Reconhecimento de voz trabalha em 16 kHz: junta de 3 em 3 amostras
            val r = recognizer ?: continue
            val m = n / 3
            for (i in 0 until m) {
                val j = i * 3
                down[i] = ((buf[j] + buf[j + 1] + buf[j + 2]) / 3).toShort()
            }
            try {
                if (r.acceptWaveForm(down, m)) handle(r.result)
            } catch (_: Exception) {
            }
        }
        try {
            rec.stop()
        } catch (_: Exception) {
        }
        rec.release()
    }

    /**
     * Só aceita o comando se a fala foi clara e curta. Barulho, conversa e
     * música costumam virar palavras com pouca certeza; essas são ignoradas.
     */
    private fun isConfident(json: String): Boolean {
        return try {
            val words = JSONObject(json).optJSONArray("result") ?: return false
            if (words.length() == 0 || words.length() > 5) return false
            var minConf = 1.0
            for (i in 0 until words.length()) {
                val w = words.getJSONObject(i)
                if (w.optString("word") == "[unk]") return false
                minConf = minOf(minConf, w.optDouble("conf", 0.0))
            }
            val first = words.getJSONObject(0).optDouble("start", 0.0)
            val last = words.getJSONObject(words.length() - 1).optDouble("end", 0.0)
            minConf >= MIN_CONFIDENCE && (last - first) <= 2.5
        } catch (_: Exception) {
            false
        }
    }

    private fun handle(json: String) {
        if (!isConfident(json)) return
        val text = try {
            JSONObject(json).optString("text")
        } catch (_: Exception) {
            ""
        }.lowercase().trim()
        if (text.isBlank()) return
        val p = prefix
        val rest = if (p.isBlank()) text else {
            if (!text.startsWith(p)) return
            text.removePrefix(p).trim()
        }
        val words = rest.split(" ")
        val cmd = when {
            "foto" in words -> "foto"
            "marca" in words || "marcar" in words -> "marca"
            "salva" in words || "salvar" in words -> "salvar"
            "gravar" in words || "grava" in words -> "gravar"
            "parar" in words || "pare" in words -> "parar"
            else -> null
        } ?: return
        val now = System.currentTimeMillis()
        if (now - lastCommandAt < 1500) return
        lastCommandAt = now
        onCommand(cmd)
    }
}
