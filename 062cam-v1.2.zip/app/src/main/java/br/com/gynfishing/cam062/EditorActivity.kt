package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Editor de vídeo: zoom num ponto da imagem, câmera lenta e acelerado em
// quantos trechos quiser (podendo combinar zoom com velocidade), corte do
// começo e do fim e opção de tirar o som. Gera um vídeo novo; o original fica.

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class EditorActivity : Activity(), TimelineView.Listener {

    private lateinit var uri: Uri
    private lateinit var model: EditorModel
    private var rotation = 0
    private var dispW = 1080
    private var dispH = 1920

    private var mp: MediaPlayer? = null
    private var prepared = false
    private var playing = false
    private var currentSpeed = 1f
    private var surface: Surface? = null

    private lateinit var previewBox: FrameLayout
    private lateinit var holder: FrameLayout
    private lateinit var texture: TextureView
    private lateinit var frameView: ZoomFrameView
    private lateinit var badges: LinearLayout
    private lateinit var badgeZoom: TextView
    private lateinit var badgeSpeed: TextView
    private lateinit var playIcon: FrameLayout
    private lateinit var timeLabel: TextView
    private lateinit var timeline: TimelineView
    private lateinit var soundLabel: TextView
    private lateinit var soundIconBox: FrameLayout
    private lateinit var sheet: LinearLayout
    private var rangeLabel: TextView? = null
    private lateinit var busy: FrameLayout
    private lateinit var busyText: TextView
    private lateinit var busyButtons: LinearLayout

    private var exporter: VideoExporter? = null
    private var savedUri: Uri? = null
    private var lastBack = 0L
    private val main = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = Ui062.dp(this, v)

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            main.postDelayed(this, 33)
        }
    }

    private val progressTicker = object : Runnable {
        override fun run() {
            val e = exporter ?: return
            val p = e.progress()
            busyText.text = if (p >= 0) "Gerando o vídeo editado... $p%" else "Gerando o vídeo editado..."
            main.postDelayed(this, 400)
        }
    }

    // ------------------------------------------------------------------ início

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui062.BG
        window.navigationBarColor = Ui062.BG

        val u = readUri()
        if (u == null) {
            Toast.makeText(this, "Nenhum vídeo para editar", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        uri = u
        val duration = readInfo()
        if (duration <= 0L) {
            Toast.makeText(this, "Não consegui abrir este vídeo", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        model = EditorModel(duration)
        build()
        loadThumbs()
    }

    private fun readUri(): Uri? {
        intent.getStringExtra("uri")?.let { return Uri.parse(it) }
        intent.data?.let { return it }
        if (intent.action == Intent.ACTION_SEND) {
            return if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            }
        }
        return null
    }

    /** Lê duração, tamanho e giro do vídeo. Devolve a duração em ms. */
    private fun readInfo(): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1920
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1080
            rotation = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rotation % 180 != 0) {
                dispW = h
                dispH = w
            } else {
                dispW = w
                dispH = h
            }
            dur
        } catch (_: Exception) {
            0L
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun loadThumbs() {
        Thread {
            val n = 10
            val list = MutableList<Bitmap?>(n) { null }
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(this, uri)
                val cellW = 120
                val cellH = (cellW * dispH / dispW.coerceAtLeast(1)).coerceIn(60, 240)
                for (i in 0 until n) {
                    val t = model.durationMs * 1000L * (2 * i + 1) / (2 * n)
                    list[i] = try {
                        r.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, cellW, cellH)
                    } catch (_: Exception) {
                        null
                    }
                    val snapshot = list.toList()
                    main.post { if (!isFinishing) timeline.thumbs = snapshot }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    r.release()
                } catch (_: Exception) {
                }
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        if (::timeline.isInitialized) main.post(ticker)
    }

    override fun onPause() {
        main.removeCallbacks(ticker)
        pause()
        super.onPause()
    }

    override fun onDestroy() {
        main.removeCallbacks(progressTicker)
        exporter?.cancel()
        exporter = null
        try {
            mp?.release()
        } catch (_: Exception) {
        }
        mp = null
        surface?.release()
        surface = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (::busy.isInitialized && busy.visibility == View.VISIBLE && exporter != null) {
            Toast.makeText(this, "Aguarde terminar ou toque em Cancelar", Toast.LENGTH_SHORT).show()
            return
        }
        val now = System.currentTimeMillis()
        if (::model.isInitialized && model.hasChanges() && savedUri == null && now - lastBack > 2500) {
            lastBack = now
            Toast.makeText(this, "Toque em voltar de novo para sair sem salvar", Toast.LENGTH_SHORT).show()
            return
        }
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    // ------------------------------------------------------------------ reprodução

    private fun setupPlayer(st: SurfaceTexture) {
        if (mp != null) return
        surface = Surface(st)
        val p = MediaPlayer()
        mp = p
        try {
            p.setDataSource(this, uri)
            p.setSurface(surface)
            p.setOnPreparedListener {
                prepared = true
                it.seekTo(0L, MediaPlayer.SEEK_CLOSEST)
            }
            p.setOnCompletionListener {
                playing = false
                updatePlayIcon()
            }
            p.setOnErrorListener { _, _, _ ->
                Toast.makeText(this, "Não consegui tocar a prévia", Toast.LENGTH_SHORT).show()
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            Toast.makeText(this, "Não consegui tocar a prévia: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun position(): Long = try {
        if (prepared) (mp?.currentPosition ?: 0).toLong() else 0L
    } catch (_: Exception) {
        0L
    }

    private fun seek(ms: Long) {
        if (!prepared) return
        try {
            mp?.seekTo(ms, MediaPlayer.SEEK_CLOSEST)
        } catch (_: Exception) {
        }
        timeline.playheadMs = ms
    }

    private fun togglePlay() {
        if (playing) pause() else play()
    }

    private fun play() {
        val p = mp ?: return
        if (!prepared) return
        val pos = position()
        if (pos < model.trimStart || pos >= model.trimEnd - 150) seek(model.trimStart)
        try {
            p.start()
            playing = true
            currentSpeed = -1f
            applySpeed(position())
        } catch (_: Exception) {
        }
        updatePlayIcon()
    }

    private fun pause() {
        if (!playing) return
        try {
            mp?.pause()
        } catch (_: Exception) {
        }
        playing = false
        updatePlayIcon()
    }

    private fun applySpeed(pos: Long) {
        val s = model.speedAt(pos)
        if (s == currentSpeed) return
        currentSpeed = s
        try {
            val p = mp ?: return
            p.playbackParams = p.playbackParams.setSpeed(s)
        } catch (_: Exception) {
        }
    }

    private fun tick() {
        if (!prepared) return
        val pos = position()
        if (playing) {
            if (pos >= model.trimEnd) {
                pause()
                seek(model.trimStart)
                return
            }
            if (pos < model.trimStart - 200) seek(model.trimStart)
            applySpeed(pos)
        }
        timeline.playheadMs = pos
        timeLabel.text = "${TimeFmt.mmss(pos)} / ${TimeFmt.mmss(model.durationMs)}"
        applyPreview(pos)
    }

    /** Mostra o zoom e a velocidade na prévia, do jeito que vai ficar. */
    private fun applyPreview(pos: Long) {
        val sel = model.selected
        val editingZoom = sel is ZoomBlock && !playing
        frameView.block = if (editingZoom) sel as ZoomBlock else null
        val st = if (editingZoom) ZoomState(1f, 0.5f, 0.5f) else model.zoomAt(pos)
        val w = texture.width.toFloat()
        val h = texture.height.toFloat()
        val m = Matrix()
        if (st.z > 1.001f && w > 0f && h > 0f) {
            m.setTranslate(-st.cu * w, -st.cv * h)
            m.postScale(st.z, st.z)
            m.postTranslate(w / 2f, h / 2f)
        }
        texture.setTransform(m)

        val zb = model.zooms.firstOrNull { pos >= it.startMs && pos <= it.endMs }
        val sb = model.speeds.firstOrNull { pos >= it.startMs && pos < it.endMs }
        badgeZoom.visibility = if (zb != null) View.VISIBLE else View.GONE
        if (zb != null) badgeZoom.text = "Zoom ${TimeFmt.factor(zb.level)}"
        badgeSpeed.visibility = if (sb != null) View.VISIBLE else View.GONE
        if (sb != null) badgeSpeed.text = (if (sb.speed < 1f) "Lento " else "Rápido ") + TimeFmt.factor(sb.speed)
    }

    private fun updatePlayIcon() {
        playIcon.removeAllViews()
        playIcon.addView(
            IconView(this, if (playing) IconView.Kind.PAUSE else IconView.Kind.PLAY, Ui062.BG),
            FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER)
        )
    }

    // ------------------------------------------------------------------ linha do tempo

    override fun onSeek(ms: Long) {
        if (playing) pause()
        seek(ms)
    }

    override fun onSelect(block: Block?) {
        if (playing) pause()
        rebuildSheet()
    }

    override fun onEditing() {
        updateRange()
    }

    override fun onEdited() {
        rebuildSheet()
    }

    // ------------------------------------------------------------------ ferramentas

    private fun addZoom() {
        val t = position().coerceIn(model.trimStart, model.trimEnd)
        val inside = model.zooms.firstOrNull { t >= it.startMs && t <= it.endMs }
        if (inside != null) {
            select(inside)
            return
        }
        val end = model.freeEnd(model.zooms, t)
        if (end - t < EditorModel.MIN_BLOCK_MS) {
            toast("Sem espaço para um zoom aqui. Mova a linha branca.")
            return
        }
        val b = ZoomBlock(t, end)
        model.zooms.add(b)
        model.zooms.sortBy { it.startMs }
        select(b)
        toast("Arraste o quadro amarelo até o ponto do zoom")
    }

    private fun addSpeed(speed: Float) {
        val t = position().coerceIn(model.trimStart, model.trimEnd)
        val inside = model.speeds.firstOrNull { t >= it.startMs && t <= it.endMs }
        if (inside != null) {
            inside.speed = speed
            select(inside)
            return
        }
        val end = model.freeEnd(model.speeds, t)
        if (end - t < EditorModel.MIN_BLOCK_MS) {
            toast("Sem espaço para outro trecho aqui. Mova a linha branca.")
            return
        }
        val b = SpeedBlock(t, end, speed)
        model.speeds.add(b)
        model.speeds.sortBy { it.startMs }
        select(b)
    }

    private fun toggleSound() {
        model.mute = !model.mute
        updateSoundTool()
        rebuildSheet()
        toast(if (model.mute) "O vídeo editado vai ficar sem som" else "Som ligado")
    }

    private fun select(b: Block?) {
        if (playing) pause()
        model.selected = b
        if (b != null) seek(b.startMs)
        timeline.invalidate()
        rebuildSheet()
    }

    private fun updateSoundTool() {
        soundIconBox.removeAllViews()
        soundIconBox.addView(
            IconView(this, if (model.mute) IconView.Kind.MUTE else IconView.Kind.SOUND, if (model.mute) Ui062.RED_SOFT else Ui062.TEXT),
            FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
        )
        soundLabel.text = if (model.mute) "Sem som" else "Som"
        soundLabel.setTextColor(if (model.mute) Ui062.RED_SOFT else Ui062.TEXT)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ salvar

    private fun save() {
        if (!model.hasChanges()) {
            toast("Nada para salvar ainda: crie um zoom, velocidade ou corte")
            return
        }
        pause()
        model.selected = null
        timeline.invalidate()
        rebuildSheet()
        savedUri = null
        showBusy(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val ex = VideoExporter(
            this, uri, model, dispH > dispW, rotation,
            onDone = { u ->
                exporter = null
                savedUri = u
                main.removeCallbacks(progressTicker)
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                showDone()
            },
            onFail = { msg ->
                exporter = null
                main.removeCallbacks(progressTicker)
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                showBusy(false)
                Toast.makeText(this, "Não consegui gerar o vídeo: $msg", Toast.LENGTH_LONG).show()
            }
        )
        exporter = ex
        try {
            ex.start()
            main.post(progressTicker)
        } catch (e: Exception) {
            exporter = null
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            showBusy(false)
            Toast.makeText(this, "Não consegui gerar o vídeo: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showBusy(on: Boolean) {
        busy.visibility = if (on) View.VISIBLE else View.GONE
        busyText.text = "Gerando o vídeo editado..."
        busyButtons.removeAllViews()
        if (on) {
            busyButtons.addView(outlineButton("Cancelar") {
                exporter?.cancel()
                exporter = null
                main.removeCallbacks(progressTicker)
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                showBusy(false)
                toast("Cancelado")
            }, LinearLayout.LayoutParams(-2, dp(46)))
        }
    }

    private fun showDone() {
        busy.visibility = View.VISIBLE
        busyText.text = "Pronto! Vídeo editado salvo em Filmes/062Cam.\nO original continua guardado."
        busyButtons.removeAllViews()
        busyButtons.addView(outlineButton("Continuar editando") { busy.visibility = View.GONE },
            LinearLayout.LayoutParams(-2, dp(46)).apply { marginEnd = dp(10) })
        busyButtons.addView(yellowButton("Assistir") {
            val u = savedUri ?: return@yellowButton
            try {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (_: Exception) {
                toast("Abra a galeria do celular: Filmes/062Cam")
            }
        }, LinearLayout.LayoutParams(-2, dp(46)))
    }

    // ------------------------------------------------------------------ caixa de ajustes (embaixo)

    private fun rebuildSheet() {
        if (!::sheet.isInitialized) return
        sheet.removeAllViews()
        rangeLabel = null
        when (val b = model.selected) {
            is ZoomBlock -> {
                sheetHeader("Zoom no ponto", b)
                sheet.addView(segmented(listOf(1.5f, 2f, 3f, 4f), b.level, Ui062.YELLOW, Ui062.ON_YELLOW) {
                    b.level = it
                    b.cu = EditorModel.clampCenter(b.cu, it)
                    b.cv = EditorModel.clampCenter(b.cv, it)
                    timeline.invalidate()
                }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
                hint("Arraste o quadro amarelo na imagem até o ponto. Arraste as pontas do bloco amarelo na linha do tempo para mudar quanto tempo dura.")
            }
            is SpeedBlock -> {
                sheetHeader(if (b.speed < 1f) "Câmera lenta" else "Acelerado", b)
                sheet.addView(
                    segmented(listOf(0.25f, 0.5f, 2f, 4f), b.speed, Color.parseColor("#4FC3F7"), Color.parseColor("#04263A")) {
                        b.speed = it
                        currentSpeed = -1f
                        timeline.invalidate()
                        rebuildSheet()
                    }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
                )
                hint("0,25× e 0,5× deixam lento; 2× e 4× aceleram. Arraste as pontas do bloco azul para escolher o trecho.")
            }
            else -> {
                sheet.addView(Ui062.text(this, "Vídeo final: ${TimeFmt.mmss(model.outputDurationMs())}", 15f, Ui062.TEXT, true))
                val parts = mutableListOf<String>()
                if (model.zooms.isNotEmpty()) parts.add("${model.zooms.size} zoom")
                if (model.speeds.isNotEmpty()) parts.add("${model.speeds.size} trecho(s) de velocidade")
                if (model.trimStart > 0 || model.trimEnd < model.durationMs) parts.add("cortado")
                if (model.mute) parts.add("sem som")
                if (parts.isNotEmpty()) {
                    sheet.addView(
                        Ui062.text(this, parts.joinToString(" · "), 12f, Ui062.DIM),
                        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) }
                    )
                }
                hint(
                    "Leve a linha branca até o momento e toque em Zoom, Lento ou Acelerar. " +
                            "Pode repetir em quantos trechos quiser, e zoom e velocidade podem ficar juntos no mesmo trecho. " +
                            "Para cortar o começo e o fim, arraste as pontas amarelas da faixa de imagens."
                )
            }
        }
    }

    private fun sheetHeader(title: String, b: Block) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(Ui062.text(this, title, 15f, Ui062.TEXT, true))
        val range = Ui062.text(this, "", 12f, Ui062.DIM)
        rangeLabel = range
        texts.addView(range, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(outlineButton("Remover", Ui062.RED_SOFT) {
            model.remove(b)
            timeline.invalidate()
            rebuildSheet()
        }, LinearLayout.LayoutParams(-2, dp(38)))
        sheet.addView(row)
        updateRange()
    }

    private fun updateRange() {
        val b = model.selected ?: return
        val base = "De ${TimeFmt.mmss(b.startMs)} até ${TimeFmt.mmss(b.endMs)} · ${TimeFmt.secs(b.lengthMs)}"
        rangeLabel?.text = if (b is SpeedBlock) "$base · vira ${TimeFmt.secs(model.outputLengthOf(b))} no vídeo final" else base
    }

    private fun hint(s: String) {
        sheet.addView(
            Ui062.text(this, s, 12f, Ui062.DIM).apply { setLineSpacing(0f, 1.15f) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        )
    }

    private fun segmented(values: List<Float>, current: Float, onColor: Int, onText: Int, onPick: (Float) -> Unit): LinearLayout {
        val group = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui062.shape(context, Ui062.BG, 12)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val buttons = mutableListOf<Pair<Float, TextView>>()
        fun paint(sel: Float) {
            for ((v, b) in buttons) {
                val on = v == sel
                b.background = Ui062.shape(this, if (on) onColor else Color.TRANSPARENT, 9)
                b.setTextColor(if (on) onText else Ui062.MUTED)
                b.typeface = if (on) Ui062.BOLD else Ui062.MEDIUM
            }
        }
        for (v in values) {
            val b = Ui062.text(this, TimeFmt.factor(v), 14f).apply {
                gravity = Gravity.CENTER
                setOnClickListener {
                    paint(v)
                    onPick(v)
                }
            }
            buttons.add(v to b)
            group.addView(b, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        paint(current)
        return group
    }

    private fun outlineButton(label: String, color: Int = Ui062.TEXT, onClick: () -> Unit): TextView =
        Ui062.text(this, label, 14f, color, true).apply {
            gravity = Gravity.CENTER
            background = Ui062.shape(context, Color.TRANSPARENT, 10, Color.parseColor("#3A3A3A"), 1)
            setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener { onClick() }
        }

    private fun yellowButton(label: String, onClick: () -> Unit): TextView =
        Ui062.text(this, label, 14f, Ui062.ON_YELLOW, true).apply {
            gravity = Gravity.CENTER
            background = Ui062.shape(context, Ui062.YELLOW, 10)
            setPadding(dp(18), 0, dp(18), 0)
            setOnClickListener { onClick() }
        }

    private fun tool(kind: IconView.Kind, label: String, color: Int, onClick: () -> Unit): Pair<LinearLayout, FrameLayout> {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = Ui062.shape(context, Ui062.CARD, 12)
            isClickable = true
            contentDescription = label
            setOnClickListener { onClick() }
        }
        val icon = FrameLayout(this)
        icon.addView(IconView(this, kind, color), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        box.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
        val text = Ui062.text(this, label, 12f, color, true)
        box.addView(text, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
        return box to icon
    }

    // ------------------------------------------------------------------ montagem da tela

    private fun build() {
        val outer = FrameLayout(this).apply { setBackgroundColor(Ui062.BG) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Topo
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
        }
        val back = FrameLayout(this).apply {
            background = Ui062.shape(context, Ui062.CARD, 12)
            contentDescription = "Voltar"
            isClickable = true
            @Suppress("DEPRECATION")
            setOnClickListener { onBackPressed() }
            addView(IconView(context, IconView.Kind.BACK), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        }
        header.addView(back, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(10) })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(Ui062.text(this, "Editar vídeo", 18f, Ui062.TEXT, true))
        titles.addView(Ui062.text(this, "Duração ${TimeFmt.mmss(model.durationMs)} · o original não é alterado", 12f, Ui062.DIM))
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(yellowButton("Salvar") { save() }, LinearLayout.LayoutParams(-2, dp(40)))
        root.addView(header)

        // Prévia
        previewBox = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        holder = FrameLayout(this)
        texture = TextureView(this)
        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) = setupPlayer(st)
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        holder.addView(texture, FrameLayout.LayoutParams(-1, -1))
        frameView = ZoomFrameView(this).apply {
            visibility = View.GONE
            onMoved = { timeline.invalidate() }
        }
        holder.addView(frameView, FrameLayout.LayoutParams(-1, -1))
        previewBox.addView(holder, FrameLayout.LayoutParams(0, 0, Gravity.CENTER))
        badges = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        badgeZoom = Ui062.text(this, "", 12f, Ui062.ON_YELLOW, true).apply {
            background = Ui062.shape(context, Ui062.YELLOW, 8)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            visibility = View.GONE
        }
        badgeSpeed = Ui062.text(this, "", 12f, Color.parseColor("#04263A"), true).apply {
            background = Ui062.shape(context, Color.parseColor("#4FC3F7"), 8)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            visibility = View.GONE
        }
        badges.addView(badgeZoom, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
        badges.addView(badgeSpeed)
        previewBox.addView(badges, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            topMargin = dp(10)
            marginEnd = dp(10)
        })
        val previewH = (resources.displayMetrics.heightPixels * 0.40f).toInt()
        root.addView(previewBox, LinearLayout.LayoutParams(-1, previewH))
        previewBox.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val bw = r - l
            val bh = b - t
            if (bw <= 0 || bh <= 0) return@addOnLayoutChangeListener
            val scale = minOf(bw.toFloat() / dispW, bh.toFloat() / dispH)
            val w = (dispW * scale).toInt()
            val h = (dispH * scale).toInt()
            val lp = holder.layoutParams as FrameLayout.LayoutParams
            if (lp.width != w || lp.height != h) {
                lp.width = w
                lp.height = h
                holder.post { holder.layoutParams = lp }
            }
        }

        // Tocar + tempo
        val playRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(4))
        }
        playIcon = FrameLayout(this).apply {
            background = Ui062.oval(Ui062.TEXT)
            contentDescription = "Tocar ou pausar"
            isClickable = true
            setOnClickListener { togglePlay() }
        }
        playRow.addView(playIcon, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(12) })
        timeLabel = Ui062.text(this, "00:00 / ${TimeFmt.mmss(model.durationMs)}", 15f, Ui062.TEXT, true)
        playRow.addView(timeLabel)
        root.addView(playRow)
        updatePlayIcon()

        // Linha do tempo
        timeline = TimelineView(this, model)
        timeline.listener = this
        root.addView(timeline, LinearLayout.LayoutParams(-1, -2).apply {
            leftMargin = dp(2)
            rightMargin = dp(2)
        })

        // Ferramentas
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(12), dp(16), 0)
        }
        val (zoomTool, _) = tool(IconView.Kind.ZOOM, "Zoom", Ui062.YELLOW) { addZoom() }
        val (slowTool, _) = tool(IconView.Kind.SLOW, "Lento", Color.parseColor("#4FC3F7")) { addSpeed(0.5f) }
        val (fastTool, _) = tool(IconView.Kind.FAST, "Acelerar", Color.parseColor("#4FC3F7")) { addSpeed(2f) }
        val (soundTool, soundIcon) = tool(IconView.Kind.SOUND, "Som", Ui062.TEXT) { toggleSound() }
        soundIconBox = soundIcon
        soundLabel = soundTool.getChildAt(1) as TextView
        for ((i, t) in listOf(zoomTool, slowTool, fastTool, soundTool).withIndex()) {
            tools.addView(t, LinearLayout.LayoutParams(0, dp(62), 1f).apply { if (i < 3) marginEnd = dp(8) })
        }
        root.addView(tools)
        updateSoundTool()

        // Caixa de ajustes
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui062.shape(context, Ui062.CARD, 18)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        scroll.addView(sheet, FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            setMargins(dp(12), dp(12), dp(12), dp(12))
        })
        rebuildSheet()

        outer.addView(root, FrameLayout.LayoutParams(-1, -1))

        // Aviso de "gerando o vídeo"
        busy = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#E6050505"))
            isClickable = true
            visibility = View.GONE
        }
        val busyCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), 0, dp(24), 0)
        }
        busyText = Ui062.text(this, "", 16f, Ui062.TEXT, true).apply { gravity = Gravity.CENTER }
        busyCol.addView(busyText)
        busyCol.addView(
            Ui062.text(this, "Não feche esta tela até terminar.", 13f, Ui062.DIM).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) }
        )
        busyButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        busyCol.addView(busyButtons, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(18) })
        busy.addView(busyCol, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        outer.addView(busy, FrameLayout.LayoutParams(-1, -1))

        setContentView(outer)
    }
}
