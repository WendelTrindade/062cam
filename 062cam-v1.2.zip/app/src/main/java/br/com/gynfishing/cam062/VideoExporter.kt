package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Gera o vídeo editado no próprio celular (sem internet), usando a ferramenta
// de edição de vídeo do Google (Media3). O vídeo original não é alterado.

import android.content.ContentValues
import android.content.Context
import android.graphics.Matrix
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.Size
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Aplica o zoom quadro a quadro. Fica antes da mudança de velocidade, então
 * recebe o tempo original do vídeo.
 */
class ZoomEffect(
    private val curve: ZoomCurve,
    private val segStartMs: Long,
    private val displayPortrait: Boolean,
    private val rotation: Int
) : MatrixTransformation {

    private var t0 = Long.MIN_VALUE
    private var rawFrames = false

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        // Se o quadro ainda não foi girado para ficar em pé, corrige o ponto do zoom
        val inPortrait = inputHeight > inputWidth
        rawFrames = rotation % 180 != 0 && inPortrait != displayPortrait
        return Size(inputWidth, inputHeight)
    }

    override fun getMatrix(presentationTimeUs: Long): Matrix {
        if (t0 == Long.MIN_VALUE || presentationTimeUs < t0) t0 = presentationTimeUs
        val srcMs = segStartMs + (presentationTimeUs - t0) / 1000
        val st = curve.zoomAt(srcMs)
        val m = Matrix()
        if (st.z <= 1.001f) return m
        var u = st.cu
        var v = st.cv
        if (rawFrames) {
            if (rotation == 90) {
                val ru = v
                val rv = 1f - u
                u = ru
                v = rv
            } else if (rotation == 270) {
                val ru = 1f - v
                val rv = u
                u = ru
                v = rv
            }
        }
        val cx = 2f * u - 1f
        val cy = 1f - 2f * v
        m.setTranslate(-cx, -cy)
        m.postScale(st.z, st.z)
        return m
    }
}

class VideoExporter(
    private val ctx: Context,
    private val uri: Uri,
    private val model: EditorModel,
    private val displayPortrait: Boolean,
    private val rotation: Int,
    private val onDone: (Uri) -> Unit,
    private val onFail: (String) -> Unit
) {
    private var transformer: Transformer? = null
    private val holder = ProgressHolder()
    private val outFile = File(ctx.cacheDir, "062cam_edicao.mp4")

    /** Precisa ser chamado na linha principal do app. */
    fun start() {
        outFile.delete()
        val curve = ZoomCurve(model.zooms)
        val items = model.segments().map { seg ->
            val mediaItem = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(seg.startMs)
                        .setEndPositionMs(seg.endMs)
                        .build()
                )
                .build()
            val video = mutableListOf<Effect>(ZoomEffect(curve, seg.startMs, displayPortrait, rotation))
            if (seg.speed != 1f) video.add(SpeedChangeEffect(seg.speed))
            val audio = mutableListOf<AudioProcessor>()
            if (!model.mute && seg.speed != 1f) {
                audio.add(SonicAudioProcessor().apply {
                    setSpeed(seg.speed)
                    setPitch(1f)
                })
            }
            EditedMediaItem.Builder(mediaItem)
                .setRemoveAudio(model.mute)
                .setEffects(Effects(audio, video))
                .build()
        }
        if (items.isEmpty()) {
            onFail("O trecho escolhido está vazio")
            return
        }
        val composition = Composition.Builder(listOf(EditedMediaItemSequence(items))).build()
        val t = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    saveToGallery()
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    onFail("${exportException.message ?: "erro"} (código ${exportException.errorCode})")
                }
            })
            .build()
        transformer = t
        t.start(composition, outFile.absolutePath)
    }

    /** Progresso de 0 a 100, ou -1 se ainda não souber. */
    fun progress(): Int {
        val t = transformer ?: return -1
        return try {
            if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) holder.progress else -1
        } catch (_: Exception) {
            -1
        }
    }

    fun cancel() {
        try {
            transformer?.cancel()
        } catch (_: Exception) {
        }
        transformer = null
        outFile.delete()
    }

    private fun saveToGallery() {
        Thread {
            var dest: Uri? = null
            try {
                val name = "062Cam_editado_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/" + CameraEngine.FOLDER)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val resolver = ctx.contentResolver
                dest = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw Exception("sem espaço para salvar")
                resolver.openOutputStream(dest)?.use { out ->
                    FileInputStream(outFile).use { it.copyTo(out) }
                } ?: throw Exception("não abriu o arquivo")
                val done = ContentValues()
                done.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(dest, done, null, null)
                outFile.delete()
                val result = dest
                android.os.Handler(android.os.Looper.getMainLooper()).post { onDone(result) }
            } catch (e: Exception) {
                val d = dest
                if (d != null) try {
                    ctx.contentResolver.delete(d, null, null)
                } catch (_: Exception) {
                }
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    onFail("Não consegui salvar na galeria: ${e.message}")
                }
            }
        }.start()
    }
}
