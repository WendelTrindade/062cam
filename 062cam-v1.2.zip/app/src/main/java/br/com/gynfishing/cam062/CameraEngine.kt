package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Motor da câmera. A câmera e o microfone ficam ligados o tempo todo,
// codificando vídeo e áudio. Os últimos segundos ficam guardados na memória
// (pré-gravação). Quando o usuário manda gravar, esses segundos são gravados
// no arquivo e a gravação continua ao vivo.

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.location.Location
import android.media.ExifInterface
import android.media.ImageReader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Surface
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class CameraEngine(private val ctx: Context, private val events: Events) {

    interface Events {
        fun onInfo(msg: String)
        fun onRecordingChanged(recording: Boolean)
        fun onSaved(isVideo: Boolean, name: String, uri: Uri, marks: List<Long>)
        fun onCameraReady()
    }

    private class Sample(val video: Boolean, val data: ByteArray, val pts: Long, val flags: Int) {
        val key: Boolean get() = (flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
    }

    companion object {
        const val SAMPLE_RATE = 48000
        const val FOLDER = "062Cam"
    }

    private val camThread = HandlerThread("camera").apply { start() }
    private val camHandler = Handler(camThread.looper)
    private val manager = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    @Volatile var preRecSec = 15
    @Volatile var useHdr = false
    @Volatile var useStab = true
    @Volatile var quality1080 = true
    @Volatile var zoom = 1f

    /** Última localização conhecida (vai dentro do vídeo e no carimbo da foto). */
    @Volatile var location: Location? = null
    /** Quando não é nulo, devolve as linhas do carimbo desenhado nas fotos. */
    @Volatile var photoStamp: (() -> List<String>)? = null
    private val marks = mutableListOf<Long>()

    @Volatile var hdrSupported = false
        private set
    @Volatile var stabSupported = false
        private set
    @Volatile var ultraWideSupported = false
        private set
    private var zoomRange: Range<Float>? = null
    private var activeArray: Rect? = null
    private var maxDigitalZoom = 1f
    @Volatile var useFront = false
        private set
    @Volatile var videoSize = Size(1920, 1080)
        private set
    private var sensorOrientation = 90
    @Volatile private var realtimeClock = false
    private var fpsRange: Range<Int>? = null
    private var afVideo = false

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    @Volatile private var videoEncoder: MediaCodec? = null
    private var videoDrain: Thread? = null
    private var encoderSurface: Surface? = null
    private var imageReader: ImageReader? = null
    private var previewTexture: SurfaceTexture? = null
    private var previewSurface: Surface? = null

    @Volatile private var audioEncoder: MediaCodec? = null
    private var audioDrain: Thread? = null

    private val lock = Object()
    private val videoRing = ArrayDeque<Sample>()
    private val audioRing = ArrayDeque<Sample>()
    private var videoFormat: MediaFormat? = null
    private var audioFormat: MediaFormat? = null

    private var muxer: MediaMuxer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var videoUri: Uri? = null
    private var videoName = ""
    private var vTrack = -1
    private var aTrack = -1
    private var muxStarted = false
    private var startPts = 0L
    private var lastV = -1L
    private var lastA = -1L
    private var samplesWritten = 0

    @Volatile var isRecording = false
        private set
    @Volatile var recStartMs = 0L
        private set

    init {
        // Descobre qual relógio a câmera usa, para o áudio andar junto com o vídeo
        try {
            val id = manager.cameraIdList.firstOrNull()
            if (id != null) {
                val ch = manager.getCameraCharacteristics(id)
                realtimeClock = ch.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE) ==
                        CameraMetadata.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME
            }
        } catch (_: Exception) {
        }
    }

    /** Hora atual (microssegundos) no mesmo relógio usado pelos quadros da câmera. */
    fun nowUs(): Long =
        if (realtimeClock) SystemClock.elapsedRealtimeNanos() / 1000 else System.nanoTime() / 1000

    // ------------------------------------------------------------------ ciclo de vida

    fun start(front: Boolean) {
        camHandler.post {
            startAudioEncoder()
            openCamera(front)
        }
    }

    /** Reaplica HDR, estabilização e zoom sem reiniciar a câmera. */
    fun applyLiveSettings() {
        camHandler.post { startRepeating() }
    }

    fun setZoomLevel(z: Float) {
        camHandler.post {
            zoom = z
            startRepeating()
        }
    }

    /** Reinicia a câmera (usado quando muda a qualidade). */
    fun restart() {
        switchCamera(useFront)
    }

    fun switchCamera(front: Boolean) {
        if (isRecording) {
            events.onInfo("Pare a gravação antes de mudar a câmera")
            return
        }
        camHandler.post {
            closeCamera()
            stopVideoEncoder()
            synchronized(lock) {
                videoRing.clear()
                audioRing.clear()
                videoFormat = null
            }
            openCamera(front)
        }
    }

    fun release() {
        if (isRecording) stopRecording()
        val latch = CountDownLatch(1)
        camHandler.post {
            closeCamera()
            stopVideoEncoder()
            stopAudioEncoder()
            previewSurface?.release()
            previewSurface = null
            previewTexture = null
            latch.countDown()
        }
        latch.await(2, TimeUnit.SECONDS)
        camThread.quitSafely()
    }

    // ------------------------------------------------------------------ prévia na tela

    fun attachPreview(st: SurfaceTexture) {
        camHandler.post {
            if (previewTexture === st && previewSurface != null) return@post
            previewSurface?.release()
            previewTexture = st
            st.setDefaultBufferSize(videoSize.width, videoSize.height)
            previewSurface = Surface(st)
            createSession()
        }
    }

    /** Tira a prévia da câmera e espera terminar, antes da tela sumir. */
    fun detachPreview() {
        val latch = CountDownLatch(1)
        camHandler.post {
            if (previewSurface == null) {
                latch.countDown()
                return@post
            }
            try {
                session?.stopRepeating()
            } catch (_: Exception) {
            }
            try {
                session?.close()
            } catch (_: Exception) {
            }
            session = null
            previewSurface?.release()
            previewSurface = null
            previewTexture = null
            latch.countDown()
            createSession()
        }
        latch.await(800, TimeUnit.MILLISECONDS)
    }

    // ------------------------------------------------------------------ câmera

    @SuppressLint("MissingPermission")
    private fun openCamera(front: Boolean) {
        useFront = front
        try {
            val id = pickCamera(front) ?: pickCamera(!front)
            if (id == null) {
                events.onInfo("Nenhuma câmera encontrada")
                return
            }
            val ch = manager.getCameraCharacteristics(id)
            useFront = ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            sensorOrientation = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            realtimeClock = ch.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE) ==
                    CameraMetadata.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            if (map == null) {
                events.onInfo("Câmera sem configuração de vídeo")
                return
            }
            videoSize = chooseSize(map.getOutputSizes(MediaCodec::class.java) ?: emptyArray())
            fpsRange = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                ?.firstOrNull { it.lower == 30 && it.upper == 30 }
            stabSupported = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
                ?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
            hdrSupported = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES)
                ?.contains(CameraMetadata.CONTROL_SCENE_MODE_HDR) == true
            activeArray = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
            maxDigitalZoom = ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f
            zoomRange = if (Build.VERSION.SDK_INT >= 30) {
                ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
            } else null
            ultraWideSupported = (zoomRange?.lower ?: 1f) < 0.95f
            if (zoom < 1f && !ultraWideSupported) zoom = 1f
            afVideo = ch.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
                ?.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO) == true

            setupVideoEncoder()
            imageReader = ImageReader.newInstance(videoSize.width, videoSize.height, ImageFormat.JPEG, 2).apply {
                setOnImageAvailableListener({ r -> onPhotoReady(r) }, camHandler)
            }

            manager.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    device = d
                    createSession()
                }

                override fun onDisconnected(d: CameraDevice) {
                    d.close()
                    if (device === d) device = null
                    events.onInfo("A câmera foi desligada pelo sistema")
                }

                override fun onError(d: CameraDevice, error: Int) {
                    d.close()
                    if (device === d) device = null
                    events.onInfo("Erro na câmera (código $error)")
                }
            }, camHandler)
        } catch (e: Exception) {
            events.onInfo("Não consegui abrir a câmera: ${e.message}")
        }
    }

    private fun pickCamera(front: Boolean): String? {
        val want = if (front) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
        return manager.cameraIdList.firstOrNull {
            manager.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == want
        }
    }

    private fun chooseSize(sizes: Array<Size>): Size {
        if (quality1080) sizes.firstOrNull { it.width == 1920 && it.height == 1080 }?.let { return it }
        sizes.firstOrNull { it.width == 1280 && it.height == 720 }?.let { return it }
        sizes.filter { it.width * 9 == it.height * 16 && it.width <= 1920 }
            .maxByOrNull { it.width }?.let { return it }
        return sizes.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
            ?: Size(1280, 720)
    }

    private fun createSession() {
        val d = device ?: return
        try {
            session?.close()
        } catch (_: Exception) {
        }
        session = null
        val enc = encoderSurface ?: return
        val jpeg = imageReader?.surface ?: return
        previewTexture?.setDefaultBufferSize(videoSize.width, videoSize.height)
        val outputs = listOfNotNull(previewSurface, enc, jpeg)
        try {
            @Suppress("DEPRECATION")
            d.createCaptureSession(outputs, object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (device !== d) {
                        s.close()
                        return
                    }
                    session = s
                    startRepeating()
                    events.onCameraReady()
                }

                override fun onConfigureFailed(s: CameraCaptureSession) {
                    events.onInfo("Falha ao configurar a câmera")
                }
            }, camHandler)
        } catch (e: Exception) {
            events.onInfo("Erro ao iniciar a câmera: ${e.message}")
        }
    }

    private fun baseRequest(template: Int): CaptureRequest.Builder {
        val b = device!!.createCaptureRequest(template)
        if (useHdr && hdrSupported) {
            b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_USE_SCENE_MODE)
            b.set(CaptureRequest.CONTROL_SCENE_MODE, CameraMetadata.CONTROL_SCENE_MODE_HDR)
        } else {
            b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
        }
        fpsRange?.let { b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
        b.set(
            CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
            if (useStab && stabSupported) CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON
            else CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF
        )
        val zr = zoomRange
        if (Build.VERSION.SDK_INT >= 30 && zr != null) {
            b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom.coerceIn(zr.lower, zr.upper))
        } else {
            val aa = activeArray
            if (aa != null && zoom > 1f) {
                val z = zoom.coerceAtMost(maxDigitalZoom)
                val w = (aa.width() / z).toInt()
                val h = (aa.height() / z).toInt()
                val cx = aa.centerX()
                val cy = aa.centerY()
                b.set(CaptureRequest.SCALER_CROP_REGION, Rect(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2))
            }
        }
        if (afVideo) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
        }
        return b
    }

    private fun startRepeating() {
        val s = session ?: return
        val enc = encoderSurface ?: return
        try {
            val b = baseRequest(CameraDevice.TEMPLATE_RECORD)
            previewSurface?.let { b.addTarget(it) }
            b.addTarget(enc)
            s.setRepeatingRequest(b.build(), null, camHandler)
        } catch (e: Exception) {
            events.onInfo("Erro na prévia: ${e.message}")
        }
    }

    private fun closeCamera() {
        try {
            session?.close()
        } catch (_: Exception) {
        }
        session = null
        try {
            device?.close()
        } catch (_: Exception) {
        }
        device = null
        try {
            imageReader?.close()
        } catch (_: Exception) {
        }
        imageReader = null
    }

    // ------------------------------------------------------------------ foto

    fun takePhoto() {
        camHandler.post {
            val s = session
            val jpeg = imageReader?.surface
            val enc = encoderSurface
            if (s == null || device == null || jpeg == null || enc == null) {
                events.onInfo("Câmera ainda não está pronta")
                return@post
            }
            try {
                val b = baseRequest(CameraDevice.TEMPLATE_VIDEO_SNAPSHOT)
                previewSurface?.let { b.addTarget(it) }
                b.addTarget(enc)
                b.addTarget(jpeg)
                b.set(CaptureRequest.JPEG_ORIENTATION, sensorOrientation)
                b.set(CaptureRequest.JPEG_QUALITY, 95.toByte())
                s.capture(b.build(), null, camHandler)
            } catch (e: Exception) {
                events.onInfo("Não consegui tirar a foto: ${e.message}")
            }
        }
    }

    private fun onPhotoReady(reader: ImageReader) {
        val img = try {
            reader.acquireLatestImage()
        } catch (_: Exception) {
            null
        } ?: return
        val bytes: ByteArray
        try {
            val buf = img.planes[0].buffer
            bytes = ByteArray(buf.remaining())
            buf.get(bytes)
        } finally {
            img.close()
        }
        Thread {
            try {
                val lines = photoStamp?.invoke()
                val finalBytes = if (lines.isNullOrEmpty()) bytes else stampJpeg(bytes, lines)
                val name = "062Cam_${stamp()}.jpg"
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + FOLDER)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val resolver = ctx.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw Exception("sem espaço para salvar")
                resolver.openOutputStream(uri)?.use { it.write(finalBytes) }
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                events.onSaved(false, name, uri, emptyList())
            } catch (e: Exception) {
                events.onInfo("Erro ao salvar a foto: ${e.message}")
            }
        }.start()
    }

    // ------------------------------------------------------------------ codificadores

    private fun setupVideoEncoder() {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, videoSize.width, videoSize.height)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, if (videoSize.width >= 1920) 10_000_000 else 5_000_000)
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, 30)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoderSurface = codec.createInputSurface()
        codec.start()
        videoEncoder = codec
        videoDrain = Thread({ drainLoop(codec, true) }, "video-out").apply { start() }
    }

    private fun stopVideoEncoder() {
        val codec = videoEncoder ?: return
        videoEncoder = null
        try {
            videoDrain?.join(1000)
        } catch (_: Exception) {
        }
        videoDrain = null
        try {
            codec.stop()
        } catch (_: Exception) {
        }
        try {
            codec.release()
        } catch (_: Exception) {
        }
        encoderSurface?.release()
        encoderSurface = null
    }

    private fun startAudioEncoder() {
        if (audioEncoder != null) return
        try {
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 1)
            fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            audioEncoder = codec
            audioDrain = Thread({ drainLoop(codec, false) }, "audio-out").apply { start() }
        } catch (e: Exception) {
            events.onInfo("Erro no áudio: ${e.message}")
        }
    }

    private fun stopAudioEncoder() {
        val codec = audioEncoder ?: return
        audioEncoder = null
        try {
            audioDrain?.join(1000)
        } catch (_: Exception) {
        }
        audioDrain = null
        try {
            codec.stop()
        } catch (_: Exception) {
        }
        try {
            codec.release()
        } catch (_: Exception) {
        }
    }

    /** Recebe o som do microfone (48 kHz, mono) e manda para o codificador de áudio. */
    fun feedAudio(pcm: ShortArray, n: Int, ptsUs: Long) {
        val codec = audioEncoder ?: return
        try {
            var offset = 0
            while (offset < n) {
                val idx = codec.dequeueInputBuffer(5000)
                if (idx < 0) return
                val buf = codec.getInputBuffer(idx) ?: return
                buf.clear()
                buf.order(ByteOrder.nativeOrder())
                val count = minOf(buf.remaining() / 2, n - offset)
                buf.asShortBuffer().put(pcm, offset, count)
                val pts = ptsUs + offset * 1_000_000L / SAMPLE_RATE
                codec.queueInputBuffer(idx, 0, count * 2, pts, 0)
                offset += count
            }
        } catch (_: Exception) {
        }
    }

    private fun drainLoop(codec: MediaCodec, isVideo: Boolean) {
        val info = MediaCodec.BufferInfo()
        while (if (isVideo) videoEncoder === codec else audioEncoder === codec) {
            val idx = try {
                codec.dequeueOutputBuffer(info, 10_000)
            } catch (_: Exception) {
                break
            }
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val f = codec.outputFormat
                synchronized(lock) {
                    if (isVideo) {
                        videoFormat = f
                    } else {
                        audioFormat = f
                    }
                    Unit
                }
            } else if (idx >= 0) {
                try {
                    val buf = codec.getOutputBuffer(idx)
                    val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                    if (buf != null && info.size > 0 && !isConfig) {
                        val data = ByteArray(info.size)
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        buf.get(data)
                        onSample(Sample(isVideo, data, info.presentationTimeUs, info.flags))
                    }
                    codec.releaseOutputBuffer(idx, false)
                } catch (_: Exception) {
                }
            }
        }
    }

    // ------------------------------------------------------------------ memória de pré-gravação

    private fun onSample(s: Sample) {
        synchronized(lock) {
            if (s.video) videoRing.addLast(s) else audioRing.addLast(s)
            val latest = if (videoRing.isNotEmpty()) videoRing.last().pts else s.pts
            val cutoff = latest - (preRecSec + 2) * 1_000_000L
            while (videoRing.isNotEmpty() && videoRing.first().pts < cutoff) videoRing.removeFirst()
            while (audioRing.isNotEmpty() && audioRing.first().pts < cutoff) audioRing.removeFirst()

            if (isRecording) {
                if (muxStarted) {
                    writeLocked(s)
                } else if (s.video && s.key) {
                    beginFromRing(videoRing.size - 1)
                }
            }
        }
    }

    /** Começa o arquivo a partir de um quadro-chave guardado na memória. Chamar com o lock. */
    private fun beginFromRing(index: Int) {
        startPts = videoRing[index].pts
        muxStarted = true
        for (i in index until videoRing.size) writeLocked(videoRing[i])
        for (a in audioRing) if (a.pts >= startPts) writeLocked(a)
    }

    private fun writeLocked(s: Sample) {
        val m = muxer ?: return
        val pts = s.pts - startPts
        if (pts < 0) return
        if (s.video) {
            if (pts <= lastV) return
            lastV = pts
        } else {
            if (pts <= lastA) return
            lastA = pts
        }
        val info = MediaCodec.BufferInfo()
        info.set(0, s.data.size, pts, s.flags)
        try {
            m.writeSampleData(if (s.video) vTrack else aTrack, ByteBuffer.wrap(s.data), info)
            samplesWritten++
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ gravar / parar

    fun startRecording(): Boolean {
        synchronized(lock) {
            if (isRecording) return false
            val vf = videoFormat
            val af = audioFormat
            if (vf == null || af == null) {
                events.onInfo("A câmera ainda está iniciando, tente de novo")
                return false
            }
            var uri: Uri? = null
            var fd: ParcelFileDescriptor? = null
            try {
                videoName = "062Cam_${stamp()}.mp4"
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, videoName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/" + FOLDER)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw Exception("sem espaço para salvar")
                fd = ctx.contentResolver.openFileDescriptor(uri, "rw")
                    ?: throw Exception("não abriu o arquivo")
                val m = MediaMuxer(fd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                m.setOrientationHint(sensorOrientation)
                location?.let { m.setLocation(it.latitude.toFloat(), it.longitude.toFloat()) }
                vTrack = m.addTrack(vf)
                aTrack = m.addTrack(af)
                m.start()
                muxer = m
                pfd = fd
                videoUri = uri
            } catch (e: Exception) {
                try {
                    fd?.close()
                } catch (_: Exception) {
                }
                if (uri != null) try {
                    ctx.contentResolver.delete(uri, null, null)
                } catch (_: Exception) {
                }
                events.onInfo("Não consegui criar o vídeo: ${e.message}")
                return false
            }
            lastV = -1L
            lastA = -1L
            samplesWritten = 0
            muxStarted = false
            marks.clear()
            isRecording = true
            recStartMs = System.currentTimeMillis()

            if (preRecSec > 0 && videoRing.isNotEmpty()) {
                val target = videoRing.last().pts - preRecSec * 1_000_000L
                val idx = videoRing.indexOfFirst { it.key && it.pts >= target }
                if (idx >= 0) {
                    beginFromRing(idx)
                    recStartMs = System.currentTimeMillis() - (videoRing.last().pts - startPts) / 1000
                }
            }
            if (!muxStarted) requestKeyFrame()
        }
        events.onRecordingChanged(true)
        return true
    }

    fun stopRecording(): Boolean {
        val name: String
        val ok: Boolean
        val savedUri: Uri?
        val savedMarks: List<Long>
        synchronized(lock) {
            if (!isRecording) return false
            isRecording = false
            var good = samplesWritten > 0
            try {
                if (good) muxer?.stop()
            } catch (_: Exception) {
                good = false
            }
            try {
                muxer?.release()
            } catch (_: Exception) {
            }
            muxer = null
            try {
                pfd?.close()
            } catch (_: Exception) {
            }
            pfd = null
            val uri = videoUri
            videoUri = null
            if (uri != null) {
                try {
                    if (good) {
                        val values = ContentValues()
                        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                        ctx.contentResolver.update(uri, values, null, null)
                    } else {
                        ctx.contentResolver.delete(uri, null, null)
                    }
                } catch (_: Exception) {
                }
            }
            name = videoName
            ok = good
            savedUri = uri
            savedMarks = marks.toList()
            marks.clear()
        }
        events.onRecordingChanged(false)
        if (ok && savedUri != null) events.onSaved(true, name, savedUri, savedMarks)
        else events.onInfo("Gravação curta demais, nada foi salvo")
        return true
    }

    /** Marca o momento atual da gravação. Devolve a posição em milissegundos. */
    fun addMark(): Long? {
        synchronized(lock) {
            if (!isRecording || !muxStarted || lastV < 0) return null
            val ms = lastV / 1000
            marks.add(ms)
            return ms
        }
    }

    /**
     * Salva num vídeo separado os últimos segundos guardados na memória
     * (comando "salva isso"), sem precisar estar gravando.
     */
    fun saveClip(): Boolean {
        val vf: MediaFormat
        val af: MediaFormat
        val vids: List<Sample>
        val auds: List<Sample>
        synchronized(lock) {
            if (isRecording || preRecSec <= 0 || videoRing.isEmpty()) return false
            vf = videoFormat ?: return false
            af = audioFormat ?: return false
            val target = videoRing.last().pts - preRecSec * 1_000_000L
            val idx = videoRing.indexOfFirst { it.key && it.pts >= target }
            if (idx < 0) return false
            vids = videoRing.toList().subList(idx, videoRing.size)
            val start = vids[0].pts
            auds = audioRing.filter { it.pts >= start }
        }
        val loc = location
        Thread {
            var uri: Uri? = null
            var fd: ParcelFileDescriptor? = null
            try {
                val name = "062Cam_clipe_${stamp()}.mp4"
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/" + FOLDER)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw Exception("sem espaço para salvar")
                fd = ctx.contentResolver.openFileDescriptor(uri, "rw") ?: throw Exception("não abriu o arquivo")
                val m = MediaMuxer(fd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                m.setOrientationHint(sensorOrientation)
                loc?.let { m.setLocation(it.latitude.toFloat(), it.longitude.toFloat()) }
                val vt = m.addTrack(vf)
                val at = m.addTrack(af)
                m.start()
                val start = vids[0].pts
                val info = MediaCodec.BufferInfo()
                var lv = -1L
                for (v in vids) {
                    val pts = v.pts - start
                    if (pts <= lv) continue
                    lv = pts
                    info.set(0, v.data.size, pts, v.flags)
                    m.writeSampleData(vt, ByteBuffer.wrap(v.data), info)
                }
                var la = -1L
                for (a in auds) {
                    val pts = a.pts - start
                    if (pts <= la) continue
                    la = pts
                    info.set(0, a.data.size, pts, a.flags)
                    m.writeSampleData(at, ByteBuffer.wrap(a.data), info)
                }
                m.stop()
                m.release()
                fd.close()
                fd = null
                val done = ContentValues()
                done.put(MediaStore.MediaColumns.IS_PENDING, 0)
                ctx.contentResolver.update(uri, done, null, null)
                events.onSaved(true, name, uri, emptyList())
            } catch (e: Exception) {
                try {
                    fd?.close()
                } catch (_: Exception) {
                }
                val u = uri
                if (u != null) try {
                    ctx.contentResolver.delete(u, null, null)
                } catch (_: Exception) {
                }
                events.onInfo("Não consegui salvar o clipe: ${e.message}")
            }
        }.start()
        return true
    }

    /** Desenha data, hora e localização no canto da foto. */
    private fun stampJpeg(src: ByteArray, lines: List<String>): ByteArray {
        return try {
            val opts = BitmapFactory.Options().apply { inMutable = true }
            var bmp = BitmapFactory.decodeByteArray(src, 0, src.size, opts) ?: return src
            val deg = when (ExifInterface(ByteArrayInputStream(src))
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) {
                val rot = Matrix().apply { postRotate(deg) }
                val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, rot, true)
                if (r !== bmp) bmp.recycle()
                bmp = r
            }
            if (!bmp.isMutable) bmp = bmp.copy(Bitmap.Config.ARGB_8888, true)
            val c = Canvas(bmp)
            val size = minOf(bmp.width, bmp.height) * 0.035f
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size
                color = Color.WHITE
                isFakeBoldText = true
            }
            val pad = size * 0.6f
            val lineH = size * 1.3f
            val w = lines.maxOf { textPaint.measureText(it) } + pad * 2
            val h = lineH * lines.size + pad * 1.4f
            val left = pad
            val top = bmp.height - h - pad
            val box = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 0, 0, 0) }
            c.drawRoundRect(RectF(left, top, left + w, top + h), size * 0.4f, size * 0.4f, box)
            lines.forEachIndexed { i, line ->
                textPaint.color = if (i == lines.size - 1) Color.rgb(251, 196, 3) else Color.WHITE
                c.drawText(line, left + pad, top + pad + size + i * lineH, textPaint)
            }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 93, out)
            bmp.recycle()
            out.toByteArray()
        } catch (_: Throwable) {
            src
        }
    }

    private fun requestKeyFrame() {
        try {
            videoEncoder?.setParameters(Bundle().apply {
                putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
            })
        } catch (_: Exception) {
        }
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
}
