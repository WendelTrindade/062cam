package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Tela de Ajustes. Tudo é salvo na hora e o serviço aplica sozinho.

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.content.res.ColorStateList

class SettingsActivity : Activity() {

    private val prefs by lazy { getSharedPreferences(Prefs.FILE, MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private var dndToggle: Toggle062? = null
    private var lockStatus: TextView? = null
    private var gpsToggle: Toggle062? = null
    private var marksCount: TextView? = null

    private fun dp(v: Int) = Ui062.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui062.BG
        window.navigationBarColor = Ui062.BG
        build()
    }

    override fun onResume() {
        super.onResume()
        // Ao voltar das configurações do Android, confere o que foi liberado
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted && prefs.getBoolean("dnd", false)) {
            prefs.edit().putBoolean("dnd", false).apply()
        } else if (nm.isNotificationPolicyAccessGranted && prefs.getBoolean("dnd_wanted", false)) {
            prefs.edit().putBoolean("dnd", true).putBoolean("dnd_wanted", false).apply()
        }
        dndToggle?.checked = prefs.getBoolean("dnd", false)
        gpsToggle?.checked = prefs.getBoolean("gps", false)
        val n = MarksStore.load(this).size
        marksCount?.text = if (n == 0) "Nenhum ainda" else "$n vídeo(s)"
        updateLock()
    }

    private fun hasLocation(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) {
            val ok = hasLocation()
            prefs.edit().putBoolean("gps", ok).apply()
            gpsToggle?.checked = ok
        }
    }

    private fun updateLock() {
        val ok = Ui062.batteryFree(this)
        lockStatus?.text = if (ok) "Liberado" else "Toque para liberar"
        lockStatus?.setTextColor(if (ok) Ui062.GREEN else Ui062.YELLOW)
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui062.BG)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(12))
        }
        val back = FrameLayout(this).apply {
            background = Ui062.shape(context, Ui062.CARD, 12)
            contentDescription = "Voltar"
            isClickable = true
            setOnClickListener { finish() }
            addView(IconView(context, IconView.Kind.BACK), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        }
        header.addView(back, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(12) })
        header.addView(Ui062.text(this, "Ajustes", 22f, Ui062.TEXT, true))
        root.addView(header)

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(16))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // ---------- Pré-gravação
        section("PRÉ-GRAVAÇÃO")
        content.addView(
            segmented(
                listOf("Desligada" to 0, "15 s" to 15, "30 s" to 30, "60 s" to 60),
                prefs.getInt("prerec", 15)
            ) { prefs.edit().putInt("prerec", it).apply() }
        )
        hint("Guarda os segundos antes de você dizer “gravar”, e é o tamanho do clipe do “salva isso”. Gasta mais bateria.")

        // ---------- Comandos de voz
        section("COMANDOS DE VOZ")
        val wakeNow = when (prefs.getString("wake", "")) {
            "câmera" -> 1
            "zero meia dois" -> 2
            else -> 0
        }
        val wakeHint = Ui062.text(this, "", 12f, Ui062.DIM)
        fun showWake(v: Int) {
            wakeHint.text = when (v) {
                1 -> "Diga “câmera gravar”, “câmera parar”, “câmera foto”... Evita disparos sem querer."
                2 -> "Diga “zero meia dois gravar”, “zero meia dois parar”... Evita disparos sem querer."
                else -> "Diga só “gravar”, “parar”, “foto”, “marca” ou “salva isso”."
            }
        }
        content.addView(
            segmented(listOf("Nenhuma" to 0, "Câmera" to 1, "Zero meia dois" to 2), wakeNow) {
                prefs.edit().putString("wake", when (it) {
                    1 -> "câmera"
                    2 -> "zero meia dois"
                    else -> ""
                }).apply()
                showWake(it)
            }
        )
        showWake(wakeNow)
        content.addView(wakeHint, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        // ---------- Vídeo
        section("VÍDEO")
        val video = card()
        val q = if (prefs.getString("quality", "1080") == "1080") 1080 else 720
        video.addView(rowWith("Qualidade", null, segmented(listOf("1080p" to 1080, "720p" to 720), q, compact = true) {
            prefs.edit().putString("quality", it.toString()).apply()
        }))
        line(video)
        val hdrOk = prefs.getBoolean("cap_hdr", true)
        video.addView(
            if (hdrOk) toggleRow("HDR", null, "hdr", false)
            else rowWith("HDR", "Este celular não oferece", null)
        )
        line(video)
        val stabOk = prefs.getBoolean("cap_stab", true)
        video.addView(
            if (stabOk) toggleRow("Estabilização", null, "stab", true)
            else rowWith("Estabilização", "Este celular não oferece", null)
        )
        content.addView(video)

        // ---------- Carimbo
        section("CARIMBO")
        val st = card()
        st.addView(toggleRow("Data e hora nas fotos", "Desenhado no canto da foto", "stamp", false))
        line(st)
        val gpsRow = toggleRow("Localização (GPS)", "Na foto e dentro do arquivo do vídeo", "gps", false)
        gpsToggle = gpsRow.getChildAt(gpsRow.childCount - 1) as Toggle062
        gpsToggle?.onChange = { on ->
            if (on && !hasLocation()) {
                gpsToggle?.checked = false
                requestPermissions(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 7
                )
            } else {
                prefs.edit().putBoolean("gps", on).apply()
            }
        }
        st.addView(gpsRow)
        content.addView(st)

        // ---------- Momentos marcados
        section("MOMENTOS MARCADOS")
        val mk = card()
        val marksRow = rowWith("Ver momentos marcados", "Nenhum ainda", IconView(this, IconView.Kind.CHEVRON, Ui062.DIM).apply {
            layoutParams = LinearLayout.LayoutParams(dp(18), dp(18))
        })
        marksCount = (marksRow.getChildAt(0) as LinearLayout).getChildAt(1) as TextView
        marksRow.isClickable = true
        marksRow.setOnClickListener { startActivity(Intent(this, MarksActivity::class.java)) }
        mk.addView(marksRow)
        content.addView(mk)

        // ---------- Avisos
        section("AVISOS")
        val av = card()
        av.addView(toggleRow("Bipe ao gravar e parar", null, "beep", true))
        line(av)
        av.addView(volumeRow())
        line(av)
        av.addView(toggleRow("Vibrar", null, "vibrate", true))
        line(av)
        val dndRow = toggleRow("Silenciar notificações", "Enquanto o app estiver ligado", "dnd", false)
        dndToggle = dndRow.getChildAt(dndRow.childCount - 1) as Toggle062
        dndToggle?.onChange = { on ->
            val nm = getSystemService(NotificationManager::class.java)
            if (on && !nm.isNotificationPolicyAccessGranted) {
                dndToggle?.checked = false
                prefs.edit().putBoolean("dnd_wanted", true).apply()
                try {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                } catch (_: Exception) {
                }
            } else {
                prefs.edit().putBoolean("dnd", on).apply()
            }
        }
        av.addView(dndRow)
        content.addView(av)

        // ---------- Funcionamento
        section("FUNCIONAMENTO")
        val fn = card()
        fn.addView(
            toggleRow(
                "Tela escura automática",
                "Depois de 30 s sem tocar, a tela fica preta e mostra só o aviso de que o app está ouvindo ou gravando",
                "autodark", true
            )
        )
        line(fn)
        val lockRow = rowWith("Gravar com tela bloqueada", "Toque para liberar", IconView(this, IconView.Kind.CHEVRON, Ui062.DIM).apply {
            layoutParams = LinearLayout.LayoutParams(dp(18), dp(18))
        })
        lockStatus = (lockRow.getChildAt(0) as LinearLayout).getChildAt(1) as TextView
        lockRow.isClickable = true
        lockRow.setOnClickListener { Ui062.askBatteryExemption(this) }
        fn.addView(lockRow)
        content.addView(fn)
        hint("Nos celulares Xiaomi/POCO, ative também “Início automático” nas configurações do app.")

        content.addView(
            Ui062.text(this, "062 Cam ${try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "" }} · Desenvolvido por Wendel Emílio de Souza Matias\noficial.respostas@gmail.com", 11f, Color.parseColor("#6F7A84")).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(24), 0, dp(8))
            },
            LinearLayout.LayoutParams(-1, -2)
        )

        setContentView(root)
    }

    // ------------------------------------------------------------------ peças

    private fun section(title: String) {
        content.addView(
            Ui062.text(this, title, 12f, Ui062.DIM, true).apply { letterSpacing = 0.07f },
            LinearLayout.LayoutParams(-2, -2).apply {
                topMargin = dp(18)
                bottomMargin = dp(8)
            }
        )
    }

    private fun hint(s: String) {
        content.addView(
            Ui062.text(this, s, 12f, Ui062.DIM),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        )
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui062.shape(context, Ui062.CARD, 14)
    }

    private fun line(parent: LinearLayout) {
        parent.addView(View(this).apply { setBackgroundColor(Ui062.CARD_LINE) }, LinearLayout.LayoutParams(-1, 1))
    }

    /** Linha com título (e subtítulo opcional) à esquerda e um controle à direita. */
    private fun rowWith(title: String, sub: String?, right: View?): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            minimumHeight = dp(52)
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(Ui062.text(this, title, 15f))
        if (sub != null) {
            texts.addView(Ui062.text(this, sub, 12f, Ui062.DIM), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        }
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        if (right != null) row.addView(right)
        return row
    }

    private fun toggleRow(title: String, sub: String?, key: String, def: Boolean): LinearLayout {
        val t = Toggle062(this).apply {
            checked = prefs.getBoolean(key, def)
            onChange = { prefs.edit().putBoolean(key, it).apply() }
        }
        return rowWith(title, sub, t)
    }

    private fun volumeRow(): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(Ui062.text(this, "Volume do bipe", 15f), LinearLayout.LayoutParams(0, -2, 1f))
        val value = Ui062.text(this, "${prefs.getInt("beepVol", 70)}%", 14f, Ui062.MUTED)
        top.addView(value)
        box.addView(top)
        val seek = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("beepVol", 70)
            progressTintList = ColorStateList.valueOf(Ui062.YELLOW)
            thumbTintList = ColorStateList.valueOf(Ui062.YELLOW)
            progressBackgroundTintList = ColorStateList.valueOf(Ui062.TRACK_OFF)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    value.text = "$p%"
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    prefs.edit().putInt("beepVol", sb?.progress ?: 70).apply()
                }
            })
        }
        box.addView(seek, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        return box
    }

    /** Botões lado a lado em que só um fica escolhido (amarelo). */
    private fun segmented(options: List<Pair<String, Int>>, current: Int, compact: Boolean = false, onPick: (Int) -> Unit): LinearLayout {
        val group = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui062.shape(context, Ui062.CARD, 12)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val buttons = mutableListOf<Pair<Int, TextView>>()
        fun paint(sel: Int) {
            for ((v, b) in buttons) {
                val on = v == sel
                b.background = Ui062.shape(this, if (on) Ui062.YELLOW else Color.TRANSPARENT, 9)
                b.setTextColor(if (on) Ui062.ON_YELLOW else Ui062.MUTED)
                b.typeface = if (on) Ui062.BOLD else Ui062.MEDIUM
            }
        }
        for ((label, v) in options) {
            val b = Ui062.text(this, label, 14f).apply {
                gravity = Gravity.CENTER
                setPadding(dp(if (compact) 12 else 4), 0, dp(if (compact) 12 else 4), 0)
                setOnClickListener {
                    paint(v)
                    onPick(v)
                }
            }
            buttons.add(v to b)
            group.addView(
                b,
                if (compact) LinearLayout.LayoutParams(-2, dp(36))
                else LinearLayout.LayoutParams(0, dp(42), 1f)
            )
        }
        paint(current)
        return group
    }
}
