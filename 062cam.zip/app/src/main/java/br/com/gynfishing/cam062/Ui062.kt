package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Cores da marca 062 Fish e peças de tela usadas em todas as telas do app.

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object Prefs {
    const val FILE = "cfg"
}

object Ui062 {
    val YELLOW = Color.parseColor("#FBC403")
    val YELLOW_SOFT = Color.parseColor("#FFD84D")
    val BG = Color.parseColor("#050505")
    val CARD = Color.parseColor("#141414")
    val CARD_LINE = Color.parseColor("#232323")
    val TRACK_OFF = Color.parseColor("#2E2E2E")
    val TEXT = Color.parseColor("#F2F4F6")
    val MUTED = Color.parseColor("#AEB7BF")
    val DIM = Color.parseColor("#8C97A1")
    val ON_YELLOW = Color.parseColor("#0A0A0A")
    val RED = Color.parseColor("#FF3B30")
    val RED_SOFT = Color.parseColor("#FF9A92")
    val GREEN = Color.parseColor("#2ECC71")
    val GREEN_SOFT = Color.parseColor("#7CF0A8")
    val GLASS = Color.parseColor("#B8050505")
    val GLASS_LINE = Color.parseColor("#29FFFFFF")

    val BOLD: Typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    val MEDIUM: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()
    fun dpf(ctx: Context, v: Float): Float = v * ctx.resources.displayMetrics.density

    fun shape(ctx: Context, color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dpf(ctx, radiusDp.toFloat())
            if (strokeDp > 0) setStroke(dp(ctx, strokeDp), strokeColor)
        }

    fun oval(color: Int, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            if (strokePx > 0) setStroke(strokePx, strokeColor)
        }

    fun text(ctx: Context, s: String, sizeSp: Float, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = s
            textSize = sizeSp
            setTextColor(color)
            typeface = if (bold) BOLD else Typeface.DEFAULT
        }

    fun hasPermissions(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
                ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun neededPermissions(): Array<String> {
        val list = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list.toTypedArray()
    }

    fun batteryFree(ctx: Context): Boolean =
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

    fun askBatteryExemption(act: Activity) {
        try {
            act.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${act.packageName}"))
            )
        } catch (_: Exception) {
            try {
                act.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
            }
        }
    }

    /** Pílula escura e translúcida usada por cima da imagem da câmera. */
    fun pill(ctx: Context, strokeColor: Int = GLASS_LINE): LinearLayout =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = shape(ctx, GLASS, 999, strokeColor, 1)
            setPadding(dp(ctx, 12), dp(ctx, 7), dp(ctx, 14), dp(ctx, 7))
        }

    fun badge(ctx: Context, s: String): TextView =
        text(ctx, s, 11f, TEXT, true).apply {
            background = shape(ctx, GLASS, 6, GLASS_LINE, 1)
            setPadding(dp(ctx, 8), dp(ctx, 4), dp(ctx, 8), dp(ctx, 4))
        }
}

/** Ícones desenhados no próprio app (sem depender de internet). */
class IconView(ctx: Context, private val kind: IconView.Kind, var color: Int = Ui062.TEXT) : View(ctx) {
    enum class Kind { GEAR, SWITCH, CAMERA, LOCK, BACK, CHEVRON, HISTORY }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        val u = s / 24f
        p.color = color
        p.strokeWidth = 1.9f * u
        fun x(v: Float) = ox + v * u
        fun y(v: Float) = oy + v * u
        when (kind) {
            Kind.GEAR -> {
                c.drawCircle(x(12f), y(12f), 3.2f * u, p)
                c.drawCircle(x(12f), y(12f), 7.5f * u, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val cx = 12f + 7.5f * Math.cos(a).toFloat()
                    val cy = 12f + 7.5f * Math.sin(a).toFloat()
                    val ex = 12f + 10f * Math.cos(a).toFloat()
                    val ey = 12f + 10f * Math.sin(a).toFloat()
                    c.drawLine(x(cx), y(cy), x(ex), y(ey), p)
                }
            }
            Kind.SWITCH -> {
                c.drawArc(RectF(x(4f), y(4f), x(20f), y(20f)), 200f, 130f, false, p)
                c.drawArc(RectF(x(4f), y(4f), x(20f), y(20f)), 20f, 130f, false, p)
                c.drawLine(x(4.5f), y(5f), x(4.8f), y(9.3f), p)
                c.drawLine(x(4.8f), y(9.3f), x(9f), y(9f), p)
                c.drawLine(x(19.5f), y(19f), x(19.2f), y(14.7f), p)
                c.drawLine(x(19.2f), y(14.7f), x(15f), y(15f), p)
            }
            Kind.CAMERA -> {
                c.drawRoundRect(RectF(x(3f), y(7f), x(21f), y(19.5f)), 2f * u, 2f * u, p)
                c.drawLine(x(8f), y(7f), x(9.5f), y(4.5f), p)
                c.drawLine(x(9.5f), y(4.5f), x(14.5f), y(4.5f), p)
                c.drawLine(x(14.5f), y(4.5f), x(16f), y(7f), p)
                c.drawCircle(x(12f), y(13f), 3.5f * u, p)
            }
            Kind.LOCK -> {
                c.drawRoundRect(RectF(x(5f), y(11f), x(19f), y(21f)), 2f * u, 2f * u, p)
                c.drawArc(RectF(x(8f), y(4f), x(16f), y(12f)), 180f, 180f, false, p)
                c.drawLine(x(8f), y(8f), x(8f), y(11f), p)
                c.drawLine(x(16f), y(8f), x(16f), y(11f), p)
            }
            Kind.BACK -> {
                c.drawLine(x(15f), y(6f), x(9f), y(12f), p)
                c.drawLine(x(9f), y(12f), x(15f), y(18f), p)
            }
            Kind.CHEVRON -> {
                c.drawLine(x(9f), y(6f), x(15f), y(12f), p)
                c.drawLine(x(15f), y(12f), x(9f), y(18f), p)
            }
            Kind.HISTORY -> {
                c.drawArc(RectF(x(3f), y(3f), x(21f), y(21f)), 200f, 300f, false, p)
                c.drawLine(x(3.5f), y(4f), x(3.8f), y(8.5f), p)
                c.drawLine(x(3.8f), y(8.5f), x(8f), y(8.2f), p)
                c.drawLine(x(12f), y(7f), x(12f), y(12f), p)
                c.drawLine(x(12f), y(12f), x(15f), y(14f), p)
            }
        }
    }
}

/** Botão principal: círculo vermelho (vídeo), quadrado (gravando) ou branco (foto). */
class ShutterButton(ctx: Context) : View(ctx) {
    enum class Mode { VIDEO, RECORDING, PHOTO }

    var mode = Mode.VIDEO
        set(v) {
            field = v
            invalidate()
        }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Ui062.TEXT }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val stroke = s * 0.05f
        ring.strokeWidth = stroke
        c.drawCircle(cx, cy, s / 2f - stroke / 2f, ring)
        when (mode) {
            Mode.VIDEO -> {
                fill.color = Ui062.RED
                c.drawCircle(cx, cy, s * 0.38f, fill)
            }
            Mode.RECORDING -> {
                fill.color = Ui062.RED
                val h = s * 0.19f
                c.drawRoundRect(RectF(cx - h, cy - h, cx + h, cy + h), s * 0.04f, s * 0.04f, fill)
            }
            Mode.PHOTO -> {
                fill.color = Ui062.TEXT
                c.drawCircle(cx, cy, s * 0.38f, fill)
            }
        }
    }
}

/** Chave liga/desliga no visual da 062. */
class Toggle062(ctx: Context) : View(ctx) {
    var checked = false
        set(v) {
            field = v
            invalidate()
        }
    var onChange: ((Boolean) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        contentDescription = "Ligar ou desligar"
        setOnClickListener {
            checked = !checked
            onChange?.invoke(checked)
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(Ui062.dp(context, 46), Ui062.dp(context, 28))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = if (checked) Ui062.YELLOW else Ui062.TRACK_OFF
        c.drawRoundRect(RectF(0f, 0f, w, h), h / 2f, h / 2f, p)
        val r = h / 2f - Ui062.dpf(context, 3f)
        p.color = if (checked) Ui062.ON_YELLOW else Ui062.DIM
        val cx = if (checked) w - h / 2f else h / 2f
        c.drawCircle(cx, h / 2f, r, p)
    }
}
