package br.com.gynfishing.cam062

// 062 Cam — Desenvolvido por Wendel Emílio de Souza Matias (oficial.respostas@gmail.com)
//
// Serviço que mantém câmera e microfone ligados mesmo com a tela bloqueada.
// Os ajustes feitos na tela de Ajustes são aplicados aqui na hora.

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.Manifest
import android.annotation.SuppressLint
import android.app.Service
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CamService : Service(), CameraEngine.Events {

    interface Ui {
        fun onState()
        fun onMessage(msg: String)
        fun onPhotoSaved()
        fun onExit()
    }

    companion object {
        const val ACTION_TOGGLE = "br.com.gynfishing.cam062.TOGGLE"
        const val ACTION_EXIT = "br.com.gynfishing.cam062.EXIT"
        private const val CHANNEL = "camera"
        private const val NOTIF_ID = 62
    }

    inner class LocalBinder : Binder() {
        val service: CamService get() = this@CamService
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    lateinit var engine: CameraEngine
        private set
    private lateinit var prefs: SharedPreferences
    private var voice: VoiceEngine? = null
    private var started = false
    private var shutDown = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var tone: ToneGenerator? = null
    private var savedFilter: Int? = null
    private var gpsOn = false
    private val locListener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            engine.location = loc
        }

        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}

        @Deprecated("Deprecated in Java")
        @Suppress("OVERRIDE_DEPRECATION")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    var ui: Ui? = null
    var voiceStatus = "Iniciando..."
        private set
    var voiceReady = false
        private set
    var lastUri: Uri? = null
        private set
    var lastIsVideo = true
        private set

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
        when (key) {
            "prerec" -> engine.preRecSec = p.getInt("prerec", 15)
            "hdr" -> {
                engine.useHdr = p.getBoolean("hdr", false)
                engine.applyLiveSettings()
            }
            "stab" -> {
                engine.useStab = p.getBoolean("stab", true)
                engine.applyLiveSettings()
            }
            "quality" -> {
                engine.quality1080 = p.getString("quality", "1080") == "1080"
                engine.restart()
            }
            "beepVol" -> makeTone()
            "dnd" -> applyDnd()
            "wake" -> voice?.setPrefix(p.getString("wake", "") ?: "")
            "gps" -> applyGps()
        }
        main.post { ui?.onState() }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(Prefs.FILE, MODE_PRIVATE)
        engine = CameraEngine(this, this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Câmera ligada", NotificationManager.IMPORTANCE_LOW)
        )
        makeTone()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> {
                if (started) toggleRecording()
                return START_NOT_STICKY
            }
            ACTION_EXIT -> {
                shutdown()
                return START_NOT_STICKY
            }
        }
        if (!started) {
            started = true
            startForeground(NOTIF_ID, buildNotification(), fgTypes())
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "062cam:camera").apply {
                setReferenceCounted(false)
                acquire()
            }
            engine.preRecSec = prefs.getInt("prerec", 15)
            engine.useHdr = prefs.getBoolean("hdr", false)
            engine.useStab = prefs.getBoolean("stab", true)
            engine.quality1080 = prefs.getString("quality", "1080") == "1080"
            engine.zoom = prefs.getFloat("zoom", 1f)
            engine.photoStamp = { stampLines() }
            engine.start(prefs.getBoolean("front", false))
            applyDnd()
            applyGps()
            voice = VoiceEngine(
                this, engine,
                onCommand = { cmd -> main.post { onVoice(cmd) } },
                onStatus = { st ->
                    main.post {
                        voiceReady = st == VoiceEngine.READY
                        voiceStatus = if (voiceReady) "pronto" else st
                        ui?.onState()
                    }
                }
            ).also {
                it.setPrefix(prefs.getString("wake", "") ?: "")
                it.start()
            }
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ comandos

    private fun onVoice(cmd: String) {
        when (cmd) {
            "gravar" -> if (engine.isRecording) {
                beep(ToneGenerator.TONE_PROP_NACK) // já está gravando
            } else startRec()
            "parar" -> if (engine.isRecording) stopRec()
            "foto" -> photo()
            "marca" -> mark()
            "salvar" -> saveClip()
        }
    }

    /** Frase de exemplo com a palavra de ativação, para mostrar na tela. */
    fun say(cmd: String): String {
        val w = prefs.getString("wake", "") ?: ""
        return if (w.isBlank()) cmd else "$w $cmd"
    }

    fun mark() {
        val ms = engine.addMark()
        if (ms == null) {
            ui?.onMessage(if (engine.isRecording) "Aguarde um instante e marque de novo" else "Só dá para marcar durante a gravação")
            return
        }
        beep(ToneGenerator.TONE_PROP_PROMPT)
        vibrate(40)
        ui?.onMessage("Momento marcado em ${MarksStore.fmt(ms)}")
    }

    fun saveClip() {
        when {
            engine.isRecording -> {
                mark()
                return
            }
            engine.preRecSec <= 0 -> {
                beep(ToneGenerator.TONE_PROP_NACK)
                ui?.onMessage("Ligue a pré-gravação nos Ajustes para usar o \"salva isso\"")
                return
            }
        }
        if (engine.saveClip()) {
            beep(ToneGenerator.TONE_PROP_ACK)
            vibrate(60)
            ui?.onMessage("Salvando os últimos ${engine.preRecSec} s...")
        } else {
            ui?.onMessage("A câmera ainda está iniciando, tente de novo")
        }
    }

    fun toggleRecording() {
        if (engine.isRecording) stopRec() else startRec()
    }

    fun startRec() {
        if (engine.startRecording()) {
            beep(ToneGenerator.TONE_PROP_BEEP)
            vibrate(80)
        }
    }

    fun stopRec() {
        if (engine.stopRecording()) {
            beep(ToneGenerator.TONE_PROP_BEEP2)
            vibrate(200)
        }
    }

    fun photo() {
        engine.takePhoto()
        beep(ToneGenerator.TONE_PROP_ACK)
        vibrate(40)
    }

    fun setZoom(z: Float) {
        prefs.edit().putFloat("zoom", z).apply()
        engine.setZoomLevel(z)
        ui?.onState()
    }

    fun switchLens() {
        if (engine.isRecording) {
            ui?.onMessage("Pare a gravação antes de trocar a câmera")
            return
        }
        val front = !engine.useFront
        prefs.edit().putBoolean("front", front).putFloat("zoom", 1f).apply()
        engine.zoom = 1f
        engine.switchCamera(front)
    }

    fun shutdown() {
        if (shutDown) return
        shutDown = true
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        if (started) {
            if (engine.isRecording) engine.stopRecording()
            voice?.stop()
            voice = null
            engine.release()
        }
        restoreDnd()
        stopGps()
        try {
            wakeLock?.release()
        } catch (_: Exception) {
        }
        tone?.release()
        tone = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        ui?.onExit()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ localização e carimbo

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun fgTypes(): Int {
        var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (prefs.getBoolean("gps", false) && hasLocationPermission()) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        return t
    }

    @SuppressLint("MissingPermission")
    private fun applyGps() {
        if (!started || shutDown) return
        val want = prefs.getBoolean("gps", false) && hasLocationPermission()
        if (want == gpsOn) return
        if (!want) {
            stopGps()
            try {
                startForeground(NOTIF_ID, buildNotification(), fgTypes())
            } catch (_: Exception) {
            }
            return
        }
        try {
            startForeground(NOTIF_ID, buildNotification(), fgTypes())
        } catch (_: Exception) {
        }
        val lm = getSystemService(LocationManager::class.java)
        try {
            for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (!lm.isProviderEnabled(provider)) continue
                lm.getLastKnownLocation(provider)?.let { if (engine.location == null) engine.location = it }
                lm.requestLocationUpdates(provider, 10_000L, 5f, locListener, Looper.getMainLooper())
            }
            gpsOn = true
        } catch (_: Exception) {
        }
    }

    private fun stopGps() {
        if (!gpsOn) return
        gpsOn = false
        try {
            getSystemService(LocationManager::class.java).removeUpdates(locListener)
        } catch (_: Exception) {
        }
        engine.location = null
    }

    /** Linhas desenhadas na foto, ou vazio se o carimbo estiver desligado. */
    private fun stampLines(): List<String> {
        if (!prefs.getBoolean("stamp", false)) return emptyList()
        val lines = mutableListOf(SimpleDateFormat("dd/MM/yyyy  HH:mm:ss", Locale("pt", "BR")).format(Date()))
        val loc = engine.location
        if (prefs.getBoolean("gps", false) && loc != null) {
            lines.add(String.format(Locale.US, "%.5f, %.5f", loc.latitude, loc.longitude))
        }
        lines.add("062 Cam")
        return lines
    }

    // ------------------------------------------------------------------ silenciar notificações

    private fun applyDnd() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) return
        val want = prefs.getBoolean("dnd", false) && started && !shutDown
        try {
            if (want && savedFilter == null) {
                savedFilter = nm.currentInterruptionFilter
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            } else if (!want) {
                restoreDnd()
            }
        } catch (_: Exception) {
        }
    }

    private fun restoreDnd() {
        val prev = savedFilter ?: return
        savedFilter = null
        try {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(prev)
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ avisos

    private fun makeTone() {
        tone?.release()
        val vol = prefs.getInt("beepVol", 70).coerceIn(0, 100)
        tone = try {
            ToneGenerator(AudioManager.STREAM_MUSIC, vol)
        } catch (_: Exception) {
            null
        }
    }

    private fun beep(type: Int) {
        if (!prefs.getBoolean("beep", true)) return
        try {
            tone?.startTone(type, 180)
        } catch (_: Exception) {
        }
    }

    private fun vibrate(ms: Long) {
        if (!prefs.getBoolean("vibrate", true)) return
        try {
            val v = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Vibrator::class.java)
            }
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    private fun buildNotification(): Notification {
        val piFlags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), piFlags)
        val toggle = PendingIntent.getService(
            this, 1, Intent(this, CamService::class.java).setAction(ACTION_TOGGLE), piFlags
        )
        val exit = PendingIntent.getService(
            this, 2, Intent(this, CamService::class.java).setAction(ACTION_EXIT), piFlags
        )
        val rec = started && engine.isRecording
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(Ui062.YELLOW)
            .setContentTitle(if (rec) "● Gravando" else "062 Cam ligado")
            .setContentText(if (rec) "Diga \"parar\" para encerrar" else "Diga \"gravar\" para começar")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(icon, if (rec) "Parar" else "Gravar", toggle).build())
            .addAction(Notification.Action.Builder(icon, "Desligar", exit).build())
            .build()
    }

    private fun updateNotification() {
        if (!started || shutDown) return
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ eventos do motor

    override fun onInfo(msg: String) {
        main.post { ui?.onMessage(msg) }
    }

    override fun onRecordingChanged(recording: Boolean) {
        main.post {
            updateNotification()
            ui?.onState()
        }
    }

    override fun onSaved(isVideo: Boolean, name: String, uri: Uri, marks: List<Long>) {
        main.post {
            lastUri = uri
            lastIsVideo = isVideo
            if (marks.isNotEmpty()) MarksStore.add(this, uri.toString(), name, marks)
            when {
                !isVideo -> ui?.onPhotoSaved()
                marks.isNotEmpty() -> ui?.onMessage("Vídeo salvo com ${marks.size} momento(s) marcado(s)")
                name.contains("clipe") -> ui?.onMessage("Clipe salvo em Filmes/062Cam")
                else -> ui?.onMessage("Vídeo salvo em Filmes/062Cam")
            }
            ui?.onState()
        }
    }

    override fun onCameraReady() {
        prefs.edit()
            .putBoolean("cap_hdr", engine.hdrSupported)
            .putBoolean("cap_stab", engine.stabSupported)
            .putBoolean("cap_uw", engine.ultraWideSupported)
            .apply()
        main.post { ui?.onState() }
    }
}
